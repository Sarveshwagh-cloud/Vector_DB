# FD001 to FD004 Subset Profiles

## Purpose

This document gives a detailed, subset-by-subset profile for FD001 through FD004, and it is one of the most consequential Domain RAG documents because subset complexity changes how a case should be retrieved, explained, and acted on. It matters because treating FD001 and FD004 as interchangeable would misstate both the uncertainty and the failure-mode possibilities of a case. Use it on every case where the subset is known, to select the matching profile and calibrate caution. The counts and conditions below follow the NASA dataset description and the PHM 2008 paper.

## FD001

FD001 contains 100 training trajectories and 100 test trajectories, with one operating condition and a single fault mode, High Pressure Compressor degradation. Because both the operating condition and the fault mode are singular, sensor baselines are stable and the degradation trend is the dominant, easily read signal, which makes FD001 the simplest subset and the natural starting point for modeling. For recommendations this means uncertainty is typically lowest here, the point prediction can be weighted more, and FD001 similar cases are highly relevant to FD001 inference payloads. Use FD001 as the low-complexity baseline against which the harder subsets are contrasted.

## FD002

FD002 contains 260 training trajectories and 259 test trajectories, with six operating conditions and the single HPC fault mode. The six conditions mean sensor readings shift substantially with operating regime, so the degradation trend is partly hidden behind regime effects and only becomes clear after condition-aware normalization. For recommendations this raises expected uncertainty and argues for leaning on the conservative bound and for preferring similar cases from comparable operating-condition context. Use FD002 to explain why a multi-condition case can be noisier than an FD001 case with the same point prediction.

## FD003

FD003 contains 100 training trajectories and 100 test trajectories, with one operating condition but two fault modes, HPC degradation and fan degradation. The single condition keeps baselines stable, but the presence of two fault modes turns failure-mode interpretation into a real question rather than a foregone conclusion. For recommendations this means failure-mode evidence should be retrieved whenever a low TTE or a strong SHAP-driven degradation signal appears, so the explanation can attribute the degradation to the more likely mode. Use FD003 to remind the recommender not to assume HPC by default once two modes are possible.

## FD004

FD004 contains 248 training trajectories and 249 test trajectories, with six operating conditions and two fault modes, making it the most complex subset because it combines regime mixing with fault-mode ambiguity. Here sensor readings shift with both operating condition and which fault is developing, so both condition-aware normalization and failure-mode discrimination are needed at once. For recommendations on FD004 cases with low TTE, wide uncertainty, or an active UQ alarm, conservative and safety-first reasoning should be strongly considered, subject to policy evidence. Use FD004 as the high-complexity case where caution and expert review are most often warranted.

## How This Helps Recommendation Reliability

This document improves reliability by enabling subset-aware retrieval so that FD001 and FD004 are never treated as equivalent, and so the Query Router can fetch the matching profile when subset metadata is present. Matching the profile to the case is what lets the recommender calibrate uncertainty, failure-mode breadth, and conservatism correctly. The payoff is a recommendation whose caution is proportional to the genuine complexity of the subset.

## Suggested Metadata Tags

- `FD001`
- `FD002`
- `FD003`
- `FD004`
- `subset_profiles`
- `complexity`

## Source Basis

This document is grounded in authentic, citable sources: the NASA Open Data Portal entry for CMAPSS Jet Engine Simulated Data; the CMAPSSData.zip data resource; the PHM 2008 paper *Damage Propagation Modeling for Aircraft Engine Run-to-Failure Simulation* (Saxena, Goebel, Simon, Eklund, 2008; DOI 10.1109/PHM.2008.4711414; NASA DASHlink resource 740); and the *User's Guide for the Commercial Modular Aero-Propulsion System Simulation (C-MAPSS)* (Frederick, DeCastro, Litt, 2007; NASA/TM-2007-215026; NTRS 20070034949). Project-specific items (the inference output fields such as `predicted_tte`, the risk thresholds, and the custom metrics) come from this project's own inference pipeline and are labelled as project-defined, not as NASA facts. The document avoids unsupported physical mapping of individual `s1`-`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- phm08_ieee_doi: https://doi.org/10.1109/PHM.2008.4711414
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_users_guide_pdf: https://ntrs.nasa.gov/api/citations/20070034949/downloads/20070034949.pdf
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
