# Metric RAG v2: Deep CMAPSS Metric Collection with User Results

This package contains detailed Metric RAG documents for the CMAPSS recommendation system.

## Contents
- 31 detailed markdown documents
- metadata.json
- metric_rag_v2_summary.json

## Includes
- Built-in regression metrics
- UQ/conformal metrics
- Custom metrics from Custom_Metrics.py
- Weighted ensemble metrics and weights
- Saved artifact and plot interpretation docs
- User-provided full test and final inference metric references

## Mapping
`rag_knowledge_base/metric_rag/docs/` -> Qdrant collection `metric_rag`

## Design rules
1. Explain only available metrics or clearly label future metrics.
2. Do not invent anomaly_score or data_quality_score if missing.
3. SHAP and attention explain model behavior, not physical causality.
4. TMC and thresholds are project-defined unless externally validated.
5. Metric RAG explains numbers; Policy RAG decides hard actions.
