# Metric RAG Metadata Guidelines Detailed

## Purpose

This document gives detailed metadata rules for metric_rag chunks.

## Required Metadata

Each metric chunk should include collection_name, rag_type, source_id, chunk_id, source_file, metric_name, metric_category, applies_to_fields, dataset, asset_type, trust_level, source_priority, version, created_at, and updated_at.

## Metric Categories

Use categories such as prediction_output, uncertainty_quantification, regression_error, decision_metric, explainability, chart_summary, ensemble_metric, audit_artifact, future_extension, and guardrail.

## Filtering

If a final answer uses CFMR, retrieve metric_name CFMR. If it mentions lower_bound_95, retrieve uncertainty_quantification docs. If it mentions ensemble weights, retrieve ensemble metric docs.

## Source Priority

Metric RAG should usually use source_priority 4, below Policy RAG and Domain RAG for action authority, because metrics explain values but do not define hard action rules.

## How This Improves Recommendation Reliability

Metadata improves retrieval precision, source citation, evidence-quality checking, and auditability.

## Suggested Metadata Tags

- `metadata`
- `metric_category`
- `Qdrant`
- `filtering`
- `source_priority`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
