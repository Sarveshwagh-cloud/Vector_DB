# Metric Evidence Quality and Output Validation

## Purpose

This document explains quality checks for metric evidence and final LLM output.

## Metric Evidence Coverage

If the final answer mentions a metric, the evidence pack should include a document explaining that metric. Missing metric evidence should lower evidence quality.

## No Invented Values

The output validator should reject or flag final answers that invent anomaly_score, data_quality_score, or metrics not present in the payload or evidence.

## Prediction Values Unchanged

The final answer must not alter predicted_tte, lower_bound_95, confidence, risk zone, or metrics. It should quote them from the structured payload.

## Policy Boundary

Metric evidence should not be used to override Policy RAG. It can justify caution but cannot declare hard action constraints by itself.

## How This Improves Recommendation Reliability

This improves authenticity by ensuring final recommendations are metric-grounded and do not hallucinate values or unsupported claims.

## Suggested Metadata Tags

- `evidence_quality`
- `output_validator`
- `no_hallucination`
- `audit`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
