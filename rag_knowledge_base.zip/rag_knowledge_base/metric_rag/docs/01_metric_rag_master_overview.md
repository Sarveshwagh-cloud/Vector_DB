# Metric RAG Master Overview

## Purpose

This document defines the role of Metric RAG in the recommendation system and explains why metric evidence is required before the system explains model predictions, uncertainty, risk, charts, or custom evaluation outputs.

## Role of Metric RAG

Metric RAG explains numerical and model-output concepts. It explains predicted TTE, RUL, confidence, uncertainty intervals, UQ alarms, risk zones, regression metrics, custom risk metrics, chart summaries, SHAP explanations, CNN attention, ensemble weights, and audit metrics.

## Authority Boundary

Metric RAG does not decide hard actions. It explains what numbers mean and how they should influence caution. Policy RAG decides mandatory/blocked actions. Domain RAG explains CMAPSS context. Failure Mode RAG explains possible degradation modes. Similar Case RAG provides comparable cases.

## Why It Is Needed

Your inference output includes many technical fields. If the final recommendation mentions `CFMR`, `UQ_DECISION_CFMR_95`, `lower_bound_95`, `NASA_SCORE`, `SHAP`, or `w_boost`, the system must retrieve metric definitions so the LLM does not invent meanings.

## How This Improves Recommendation Reliability

Metric RAG makes the final recommendation explainable, auditable, and less likely to misuse technical terms. It supports authenticity by linking each metric in the final answer to a curated definition.

## Suggested Metadata Tags

- `metric_rag`
- `overview`
- `audit`
- `model_outputs`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
