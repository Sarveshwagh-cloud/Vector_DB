# Absolute Error Percentiles: P50AE, P75AE, P90AE, P95AE, MAX_AE

## Purpose

This document explains absolute error percentile metrics and how they support error-risk interpretation.

## Definitions

P50AE is the median absolute error. P75AE, P90AE, and P95AE show higher-percentile error magnitudes. MAX_AE shows the largest error observed in the evaluated set.

## Reported Full Test Metrics

The full test UQ run reports P90AE 20.1220, P95AE 25.0432, and MAX_AE 41.8587. This means that while average error is moderate, some cases have much larger errors.

## Reported 25-Sample Final Inference Metrics

The selected 25-sample final inference run reports P50AE 4.7288, P75AE 8.4837, P90AE 10.2168, P95AE 10.6647, and MAX_AE 11.2980. This subset had much smaller errors than the full test run.

## Recommendation Use

High P90/P95/MAX error supports conservative behavior for uncertain or near-critical cases because model error tails can affect safety decisions.

## How This Improves Recommendation Reliability

This improves reliability by showing not just average error but also tail error, which matters for safety-sensitive recommendations.

## Suggested Metadata Tags

- `P50AE`
- `P75AE`
- `P90AE`
- `P95AE`
- `MAX_AE`
- `absolute_error`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
