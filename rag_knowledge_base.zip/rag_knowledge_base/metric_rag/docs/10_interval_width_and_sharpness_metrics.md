# Interval Width and Sharpness Metrics

## Purpose

This document explains mean/median/P90 interval width metrics and their trade-off with coverage.

## Width Metrics

The pipeline reports MEAN_WIDTH_90, MEDIAN_WIDTH_90, P90_WIDTH_90, MEAN_WIDTH_95, MEDIAN_WIDTH_95, and P90_WIDTH_95. Wider intervals mean higher uncertainty or more conservative coverage.

## Full Test UQ Widths

The full test UQ run reports MEAN_WIDTH_90 = 35.9118 and MEAN_WIDTH_95 = 42.8475. P90_WIDTH_95 is 49.1156.

## 25-Sample Widths

The 25-sample final inference run reports MEAN_WIDTH_90 = 30.9180 and MEAN_WIDTH_95 = 36.7068, narrower than the full test UQ run.

## Recommendation Use

Wide intervals should increase caution. If point prediction is Safe but lower bound enters Caution or Warning, recommendations should mention UQ-aware monitoring.

## How This Improves Recommendation Reliability

This improves reliability by balancing interval specificity and safety. It prevents overconfident interpretation when uncertainty is wide.

## Suggested Metadata Tags

- `MEAN_WIDTH_95`
- `MEDIAN_WIDTH_95`
- `P90_WIDTH_95`
- `interval_width`
- `MPIW`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
