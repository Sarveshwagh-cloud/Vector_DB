# Weight Search and Validation Metrics

## Purpose

This document explains the ensemble weight-search outputs and validation/test comparison.

## Best Weight Search

The validation pseudo search selected `w_boost = 0.63` and `w_cnn = 0.37`. The reported validation score was 1.8003, validation RMSE 10.3263, MAE 6.7528, and R2 0.9556.

## Validation Metrics

Validation pseudo metrics include RMSE 10.3263, MAE 6.7528, P90AE 19.8894, P95AE 24.5578, MAX_AE 31.7856, BIAS -0.3799, R2 0.9556, NASA_SCORE 143.6078, RWE 10.9363, ARAE 13.1257, DAS 0.9184, CFMR 0.0000, RADS 0.8367.

## Test Metrics

Test clipped metrics include RMSE 11.9784, MAE 8.5395, R2 0.9107, RWE 13.0022, ARAE 17.3333, DAS 0.8400, CFMR 0.1600, DECISION_CFMR_33 0.0000, TMC 62500.

## Recommendation Use

Weight search evidence supports why the ensemble configuration was selected. It should be part of the model authenticity trace.

## How This Improves Recommendation Reliability

This improves reliability by documenting why the ensemble uses the selected weights and how validation/test behavior differs.

## Suggested Metadata Tags

- `weight_search`
- `validation_metrics`
- `test_metrics`
- `ensemble_weights`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
