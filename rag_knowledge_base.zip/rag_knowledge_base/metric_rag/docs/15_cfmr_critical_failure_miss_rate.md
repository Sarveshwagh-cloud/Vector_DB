# CFMR: Critical Failure Miss Rate

## Purpose

This document explains the project-defined custom metric `CFMR` from the user-provided Custom_Metrics.py code.

## Definition and Formula Logic

CFMR measures how often actual critical cases y_true < 30 are missed by predicted critical classification y_pred < 30. If there are no actual high-risk cases, it returns 0.

## Reported Interpretation

Full test CFMR was 0.1600, meaning 16% of actual critical cases were missed by point critical classification. In the 25-sample final inference run, CFMR was 0.0000.

## Recommendation Use

CFMR is crucial for safety because missed critical cases can be more dangerous than conservative false alarms.

## Boundary

This is a project-defined metric. It should be explained as part of this project’s evaluation framework, not as an official NASA maintenance rule.

## How This Improves Recommendation Reliability

This improves recommendation reliability by converting custom metric outputs into evidence-backed decision context.

## Suggested Metadata Tags

- `CFMR`
- `critical_failure_miss_rate`
- `missed_critical`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
