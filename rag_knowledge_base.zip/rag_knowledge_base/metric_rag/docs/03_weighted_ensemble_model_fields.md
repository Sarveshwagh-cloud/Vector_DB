# Weighted Ensemble Model Fields and Weights

## Purpose

This document explains base predictions, ensemble prediction, and ensemble weights from the weighted HGB + CNN model.

## Base Model Predictions

`boost_pred` is the HistGradientBoosting/tabular model prediction. `cnn_pred` is the CNN-BiLSTM-Attention model prediction. They may differ because one uses tabular summaries and the other uses sequence-window behavior.

## Weighted Ensemble

The ensemble combines base predictions using weights. Your reported best configuration is `w_boost = 0.63` and `w_cnn = 0.37`. The final ensemble prediction is approximately `0.63 * boost_pred + 0.37 * cnn_pred`, followed by prediction clipping where applicable.

## Weight Search Evidence

The weighted stacking search selected `w_boost = 0.63` and `w_cnn = 0.37` on validation pseudo data, with validation RMSE 10.3263, MAE 6.7528, and R2 0.9556. These validation metrics support why this ensemble weight was selected.

## Model Disagreement

The absolute difference between `boost_pred` and `cnn_pred` is a useful caution signal. For example, in the provided random UQ sample, boost predicted 98.08471 and CNN predicted 111.57127, showing notable model disagreement even though the final case was still Safe.

## How This Improves Recommendation Reliability

This improves reliability by showing how the final prediction was formed and whether the base models agreed. It supports auditability of recommendations.

## Suggested Metadata Tags

- `w_boost`
- `w_cnn`
- `boost_pred`
- `cnn_pred`
- `ensemble_pred`
- `weighted_stacking`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
