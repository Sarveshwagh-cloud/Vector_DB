# Full Test UQ Metrics Reference

## Purpose

This document stores and interprets the supplied full test Weighted Ensemble UQ metrics.

## Core Performance

Full test UQ metrics: RMSE 11.9784, MAE 8.5395, R2 0.9107, P90AE 20.1220, P95AE 25.0432, MAX_AE 41.8587, BIAS 0.2543, ABS_BIAS 0.2543.

## Uncertainty

Coverage 90 = 0.8900, Coverage 95 = 0.9400, Mean Width 90 = 35.9118, Mean Width 95 = 42.8475, UCE_90 = 0.0300, UCE_95 = 0.0200. These indicate near-target coverage with moderately wide intervals.

## Risk and Alarms

Critical alarm rate at 30 = 0.2300, at 33 = 0.2700. UQ alarm 90 rate = 0.3300 and UQ alarm 95 rate = 0.3500. UQ alarms activate more often than point critical alarms, indicating conservative risk detection.

## Custom Metrics

RWE 13.0022, ARAE 17.3333, DAS 0.8400, CFMR 0.1600, Decision CFMR@33 0.0000, UQ Decision CFMR values 0.0000, TMC 62500, EWG -0.2543, RADS 0.6400, UWE 90 = 0.4728, UWE 95 = 0.3995.

## How This Improves Recommendation Reliability

This gives the recommendation system a concrete performance baseline for the full test run and helps explain global model reliability.

## Suggested Metadata Tags

- `full_test_metrics`
- `UQ_metrics`
- `weighted_ensemble`
- `baseline_reference`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
