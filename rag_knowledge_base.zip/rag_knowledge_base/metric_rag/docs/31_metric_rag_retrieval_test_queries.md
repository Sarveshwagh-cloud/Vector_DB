# Metric RAG Retrieval Test Queries

## Purpose

This document provides test queries for validating metric_rag after Qdrant ingestion.

## UQ Query

Query: Explain q90, q95, lower_bound_95, interval_width_95, confidence, and uq_alarm_95. Expected docs: conformal quantiles, lower/upper bounds, confidence, UQ alarm.

## Custom Metrics Query

Query: Explain RWE, ARAE, DAS, CFMR, TMC, EWG, RADS, UWE, UCE, RTC, and CRR. Expected docs: all project custom metric docs.

## Ensemble Query

Query: Explain w_boost 0.63 and w_cnn 0.37 and how ensemble_pred is formed. Expected docs: weighted ensemble fields and weight-search docs.

## Audit Query

Query: Why is Decision CFMR@33 zero while point CFMR is 0.16 in full test? Expected docs: CFMR and decision CFMR docs.

## How This Improves Recommendation Reliability

This improves reliability by letting you verify retrieval behavior before connecting Metric RAG to recommendations.

## Suggested Metadata Tags

- `retrieval_tests`
- `metric_rag`
- `validation_queries`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
