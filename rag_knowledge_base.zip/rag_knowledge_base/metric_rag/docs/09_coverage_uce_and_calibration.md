# Coverage, UCE, and Calibration Interpretation

## Purpose

This document explains interval coverage and uncertainty calibration error.

## Coverage

Coverage measures how often actual TTE falls inside the prediction interval over an evaluation set. Full test UQ coverage was 0.8900 for 90% intervals and 0.9400 for 95% intervals. The 25-sample final inference run had 1.0000 coverage for both 90% and 95% intervals.

## UCE

UCE measures absolute gap between empirical coverage and target coverage. Full test UQ run has UCE_90 = 0.0300 and UCE_95 = 0.0200. The 25-sample run has UCE_90 = 0.1000 and UCE_95 = 0.0500 because empirical coverage was 1.0, above target.

## Interpretation

Coverage above target is conservative but may indicate wider intervals. Coverage below target can indicate undercoverage and less reliable intervals.

## Recommendation Use

If coverage is reliable and UCE is low, UQ intervals are stronger evidence. If UCE is high, the final recommendation should mention calibration limitations.

## How This Improves Recommendation Reliability

This improves reliability by validating whether UQ intervals behave as intended across evaluation data.

## Suggested Metadata Tags

- `COVERAGE_90`
- `COVERAGE_95`
- `UCE_90`
- `UCE_95`
- `calibration`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
