# Conformal Quantiles and Prediction Intervals

## Purpose

This document explains conformal quantiles q90/q95 and the interval fields produced by the UQ pipeline.

## Conformal Quantiles

Your UQ pipeline uses saved conformal residual quantiles. The provided runs report `conformal_q90 = 19.8894` and `conformal_q95 = 24.5578`. These values are added and subtracted from the point prediction to form uncertainty intervals, then clipped to the configured prediction range.

## 90% and 95% Intervals

The 90% interval is narrower. The 95% interval is wider and more conservative. The 95% interval is especially important for safety-oriented recommendation logic.

## Interval Fields

The inference output includes `lower_bound_90`, `upper_bound_90`, `interval_width_90`, `lower_bound_95`, `upper_bound_95`, and `interval_width_95`. Interval width is upper minus lower.

## Important Limitation

Conformal intervals are calibrated on historical/calibration data. They support coverage-oriented uncertainty but do not guarantee that a single engine’s true TTE is inside the interval.

## How This Improves Recommendation Reliability

Conformal intervals make the recommendation uncertainty-aware. They reduce overconfidence and allow the system to trigger conservative options when lower bounds are risky.

## Suggested Metadata Tags

- `conformal_q90`
- `conformal_q95`
- `lower_bound_95`
- `upper_bound_95`
- `interval_width_95`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
