# Built-In Regression Metrics: RMSE, MAE, R2

## Purpose

This document explains RMSE, MAE, and R2 and interprets the user-provided ensemble results.

## RMSE

RMSE measures the square-root average squared error in cycles. It penalizes large errors more strongly than MAE.

## MAE

MAE measures average absolute error in cycles. It is easier to interpret as average magnitude of error.

## R2

R2 describes how much variance is explained relative to a baseline. It is useful for global model fit, not case-level safety.

## Reported Test UQ Metrics

The full test UQ run reports RMSE 11.9784, MAE 8.5395, and R2 0.9107. This indicates strong global fit, but not perfect prediction. The 25-sample final inference run reports RMSE 6.4213, MAE 5.5449, and R2 0.9742 on that selected subset.

## Recommendation Boundary

Good RMSE/MAE/R2 does not by itself prove a recommendation is safe. The current case may still have high uncertainty or critical risk.

## How This Improves Recommendation Reliability

This improves reliability by preventing global metrics from being misused as proof that every single recommendation is correct.

## Suggested Metadata Tags

- `RMSE`
- `MAE`
- `R2`
- `regression_metrics`
- `test_metrics`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
