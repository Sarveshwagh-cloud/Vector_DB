# Risk Mapping Thresholds

## Purpose

This document explains the project-defined custom metric `Risk Mapping Thresholds` from the user-provided Custom_Metrics.py code.

## Definition and Formula Logic

map_risk maps TTE into Low/Medium/High risk classes using thresholds: tte < 30 is high risk class 2, 30 <= tte < 90 is medium risk class 1, and tte >= 90 is low risk class 0.

## Reported Interpretation

This mapping supports custom metrics such as DAS, CFMR, and RADS. It is project-defined and should be documented as such.

## Recommendation Use

risk mapping enables consistent metric calculation and evidence checks.

## Boundary

This is a project-defined metric. It should be explained as part of this project’s evaluation framework, not as an official NASA maintenance rule.

## How This Improves Recommendation Reliability

This improves recommendation reliability by converting custom metric outputs into evidence-backed decision context.

## Suggested Metadata Tags

- `map_risk`
- `risk_thresholds`
- `DAS`
- `CFMR`
- `RADS`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
