# Random Sample UQ Interpretation

## Purpose

This document explains how random UQ sample JSONs should be interpreted.

## Safe Sample Example

One supplied final inference random sample has unit 9, checkpoint cycle 42, predicted TTE 115.5163, actual TTE 124.0, lower_bound_95 90.9584, upper_bound_95 125.0, risk zone Safe, UQ risk Likely Safe, confidence Medium, and covered_95 true.

## Caution Sample Example

Another supplied UQ sample has actual TTE 97.0, predicted TTE 103.0747, lower_bound_95 78.5169, risk zone Safe, but UQ risk zone Possible Caution. This shows why UQ-aware status can recommend monitoring even when point risk is Safe.

## Recommendation Use

Random samples are useful for explanation examples and sanity checks, but they do not replace aggregate metrics or current-case evidence.

## How This Improves Recommendation Reliability

This improves reliability by showing how case-level prediction, uncertainty, risk, and coverage fields interact.

## Suggested Metadata Tags

- `random_sample`
- `case_level`
- `uq_sample`
- `safe`
- `possible_caution`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
