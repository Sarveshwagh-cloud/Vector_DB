# Confidence, UQ Alarm, and UQ Risk Interpretation

## Purpose

This document explains confidence labels, UQ alarm rates, and UQ-aware risk zones.

## Confidence

Your inference code derives confidence from interval width. Narrower intervals indicate higher confidence; wider intervals indicate lower confidence. Confidence is not a probability of correctness.

## UQ Alarm

A UQ alarm is active when the lower uncertainty bound crosses the alarm threshold. `uq_alarm_95` is more conservative than point risk because it uses the 95% lower bound.

## Reported Rates

In the full test UQ run, `UQ_ALARM_95_RATE = 0.3500` and `UQ_ALARM_90_RATE = 0.3300`. In the 25-sample final inference run, both UQ alarm rates were 0.1600. The difference shows that alarm rate depends on the evaluated subset or selected inference samples.

## Recommendation Use

If UQ alarm is active, the system should query Policy RAG and avoid weak actions unless allowed by policy. If UQ risk zone is Possible Caution or Possible Critical, final explanations should mention uncertainty-aware risk.

## How This Improves Recommendation Reliability

This improves reliability by giving the system a safety-aware uncertainty signal rather than relying only on point predictions.

## Suggested Metadata Tags

- `confidence`
- `uq_alarm_95`
- `uq_risk_zone_95`
- `UQ_ALARM_95_RATE`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
