# Final Inference 25-Sample Metrics Reference

## Purpose

This document stores and interprets the supplied 25-sample final inference metrics.

## Core Performance

25-sample final inference metrics: count 25, RMSE 6.4213, MAE 5.5449, R2 0.9742, P50AE 4.7288, P75AE 8.4837, P90AE 10.2168, P95AE 10.6647, MAX_AE 11.2980.

## Uncertainty

Coverage 90 and Coverage 95 are both 1.0000. Mean Width 90 = 30.9180 and Mean Width 95 = 36.7068. UCE_90 = 0.1000 and UCE_95 = 0.0500 because empirical coverage was above the nominal targets.

## Risk and Decision Metrics

Critical alarm rates and UQ alarm rates are all 0.1600. DAS = 1.0000, CFMR = 0.0000, Decision CFMR@33 = 0.0000, UQ Decision CFMR values = 0.0000, RADS = 1.0000.

## Interpretation Boundary

This selected 25-sample run performed better than the full test run. Do not assume these metrics represent all deployment data. Use them as run-specific evidence.

## How This Improves Recommendation Reliability

This improves reliability by distinguishing run-specific inference metrics from full test metrics.

## Suggested Metadata Tags

- `final_inference_metrics`
- `25_sample_run`
- `run_specific`
- `metrics_reference`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
