# Saved Metric Files and Artifacts

## Purpose

This document explains the saved metrics, tables, predictions, and metadata files produced by the ensemble and UQ pipelines.

## Metrics Files

The pipeline saves metrics JSON and CSV files for the weighted ensemble and UQ runs. These files are the authoritative source for reported model performance values.

## Prediction Files

The pipeline saves validation and test ensemble predictions, UQ prediction CSVs, and recommendation-ready prediction files. These support reproducibility and audit.

## Table Files

Saved tables include risk counts, UQ risk counts, top errors, critical cases, coverage details, top uncertain cases, and not-covered cases when available.

## Recommendation Use

The final recommendation audit pack should cite the metrics JSON/CSV path or run metadata, not only the human-readable console output.

## How This Improves Recommendation Reliability

This improves authenticity by ensuring every reported metric can be traced to a saved artifact.

## Suggested Metadata Tags

- `metrics_json`
- `metrics_csv`
- `run_metadata`
- `audit_artifacts`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
