# Residual, Bias, ABS_BIAS, and EWG

## Purpose

This document explains prediction direction metrics: residual, bias, absolute bias, and early warning gap.

## Residual

Residual is predicted TTE minus actual TTE. Positive residual means predicted remaining life is higher than actual, which can be optimistic. Negative residual means predicted remaining life is lower than actual, which can be conservative.

## Bias and ABS_BIAS

BIAS is the mean residual. ABS_BIAS is its absolute value. In the full test UQ run, BIAS was 0.2543, almost neutral but slightly optimistic. In the 25-sample final inference run, BIAS was -2.0872, slightly conservative.

## EWG

EWG is actual TTE minus predicted TTE. Positive EWG means the model predicts earlier/lower TTE on average. Negative EWG means the model predicts later/higher TTE on average. The full test run has EWG -0.2543; the 25-sample run has EWG 2.0872.

## Recommendation Use

Optimistic bias is dangerous in low-TTE cases because it can delay maintenance. Conservative bias may increase cost/downtime but can reduce missed failures.

## How This Improves Recommendation Reliability

This improves reliability by making direction of error visible rather than only magnitude.

## Suggested Metadata Tags

- `residual`
- `BIAS`
- `ABS_BIAS`
- `EWG`
- `over_prediction`
- `under_prediction`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
