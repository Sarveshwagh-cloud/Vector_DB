# Metric RAG Query Router Guidance

## Purpose

This document explains how Query Router should query metric_rag.

## When to Query

Query Metric RAG whenever final output includes prediction values, uncertainty, confidence, risk metrics, custom metrics, SHAP, attention, chart summaries, or audit metrics.

## Sparse-Heavy Retrieval

Metric RAG should use sparse-heavy hybrid retrieval because exact metric names such as CFMR, UCE, UWE, RADS, q95, and lower_bound_95 matter.

## Example Query for Current Case

For a case with predicted_tte 26, lower_bound_95 12, uq_alarm_95 true: retrieve documents about predicted TTE, conformal intervals, lower bounds, UQ alarm, confidence, and CFMR.

## Example Query for Audit

For an audit report: retrieve RMSE/MAE/R2, coverage/UCE/UWE, CFMR/Decision CFMR, NASA score, ensemble weights, and saved artifact docs.

## How This Improves Recommendation Reliability

This improves reliability by making metric evidence retrieval systematic rather than ad hoc.

## Suggested Metadata Tags

- `query_router`
- `metric_retrieval`
- `sparse_heavy`
- `audit_query`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
