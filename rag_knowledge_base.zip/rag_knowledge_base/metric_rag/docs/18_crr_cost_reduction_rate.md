# CRR: Cost Reduction Rate

## Purpose

This document explains the project-defined custom metric `CRR` from the user-provided Custom_Metrics.py code.

## Definition and Formula Logic

CRR compares model cost against a baseline cost: (baseline_cost - model_cost) / baseline_cost. It requires baseline predictions.

## Reported Interpretation

CRR was included in the custom metric code but not reported in the supplied metrics because baseline_pred was not included in those runs.

## Recommendation Use

CRR can support model comparison, but should not be invented when baseline data is unavailable.

## Boundary

This is a project-defined metric. It should be explained as part of this project’s evaluation framework, not as an official NASA maintenance rule.

## How This Improves Recommendation Reliability

This improves recommendation reliability by converting custom metric outputs into evidence-backed decision context.

## Suggested Metadata Tags

- `CRR`
- `cost_reduction_rate`
- `baseline_model`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
