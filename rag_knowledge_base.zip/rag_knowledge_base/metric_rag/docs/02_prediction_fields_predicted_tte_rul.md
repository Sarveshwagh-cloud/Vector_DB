# Prediction Fields: Predicted TTE and RUL

## Purpose

This document explains predicted TTE/RUL and the prediction fields used by the recommendation system.

## Predicted TTE

`predicted_tte` is the final point estimate of remaining cycles before the simulated failure point. In this project it is based on the weighted ensemble output after clipping.

## RUL and TTE

Remaining Useful Life and Time-to-Event both describe estimated remaining cycles. The model estimates these values from the current engine trajectory window.

## Recommendation Use

Low predicted TTE increases risk, but point prediction should not be used alone. The system must also use uncertainty bounds, confidence, UQ alarms, risk zone, policy evidence, and similar cases.

## Safe Language

Say: `The model estimates about X cycles remaining.` Do not say: `The engine will fail exactly after X cycles.`

## How This Improves Recommendation Reliability

This prevents false certainty and makes recommendations rely on point estimate plus uncertainty and evidence.

## Suggested Metadata Tags

- `predicted_tte`
- `RUL`
- `TTE`
- `point_prediction`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
