# Plot Artifact Interpretation

## Purpose

This document explains how saved plots from the weighted ensemble and UQ pipelines should be used in Metric RAG.

## Plot Types

Saved plots include actual-vs-predicted plots, residual distribution, absolute error distribution, interval width distributions, point risk-zone distribution, UQ risk-zone distribution, interval coverage, CFMR comparison, custom UQ metrics, weight-search plots, and base-vs-ensemble comparison plots.

## Chart Summaries

Raw images should not be the only evidence passed to the LLM. Your inference pipeline creates chart summaries that convert plot insights into text. Metric RAG explains how those chart summaries should be interpreted.

## Recommendation Use

Plots provide global model-behavior context. They should support explanation and audit, but case-level action still depends on the current prediction, UQ, policy, and evidence pack.

## How This Improves Recommendation Reliability

Plot interpretation improves reliability by helping reviewers understand model behavior without making unsupported case-level claims from aggregate charts.

## Suggested Metadata Tags

- `plots`
- `chart_summaries`
- `residual_distribution`
- `coverage_plot`
- `cfmr_plot`

## Source Basis

This document is grounded in the CMAPSS RUL/TTE task, the user-provided inference/ensemble/UQ metric outputs, the user-provided custom metric code, standard regression metric definitions, conformal prediction concepts, SHAP documentation, and CMAPSS prognostics benchmarking context. It treats project-defined metrics as project-defined and does not present them as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
