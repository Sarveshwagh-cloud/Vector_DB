# Failure Mode RAG Retrieval Test Queries

## Purpose

This document provides test queries for validating Failure Mode RAG retrieval.

## FD001 Query

Query: `Explain failure-mode context for FD001 low predicted TTE.` Expected: HPC degradation overview and FD001 profile.

## FD004 Query

Query: `Explain FD004 dual-fault context with low TTE and active UQ alarm.` Expected: FD004 profile, HPC/fan context, high uncertainty reasoning.

## SHAP Query

Query: `How should SHAP top sensor-derived slope features be connected to failure mode?` Expected: SHAP-to-failure-mode interpretation and sensor caution docs.

## Attention Query

Query: `How should recent CNN attention be used for degradation timing?` Expected: CNN attention to degradation timing doc.

## How This Improves Recommendation Reliability

This improves reliability by providing a validation suite before connecting Failure Mode RAG to recommendation generation.

## Suggested Metadata Tags

- `retrieval_tests`
- `failure_mode_rag`
- `validation_queries`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
