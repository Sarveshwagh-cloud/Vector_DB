# Operational Condition Effect on Failure-Mode Interpretation

## Purpose

This document explains how operating conditions affect failure-mode interpretation.

## Operating Conditions Matter

CMAPSS includes three operational settings that substantially affect engine performance. FD002 and FD004 have six operating conditions, so sensor changes can reflect operating condition as well as degradation.

## Failure-Mode Ambiguity

In multi-condition subsets, raw sensor behavior should not be treated as direct proof of a failure mode. The recommendation system should use model output, uncertainty, subset context, and similar cases filtered by operating context when possible.

## Recommendation Use

If a multi-condition case has low confidence or high uncertainty, final wording should mention that operational-condition complexity limits physical specificity and supports cautious interpretation.

## How This Improves Recommendation Reliability

This improves reliability by reducing false physical conclusions in FD002/FD004.

## Suggested Metadata Tags

- `operational_settings`
- `FD002`
- `FD004`
- `failure_mode_ambiguity`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
