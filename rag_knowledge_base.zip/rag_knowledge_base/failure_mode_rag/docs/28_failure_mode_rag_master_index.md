# Failure Mode RAG Master Index

## Purpose

This document summarizes all Failure Mode RAG documents and how the collection should be used.

## Included Topics

The collection covers official CMAPSS fault-mode scope, HPC degradation, fan degradation, single/dual-fault reasoning, FD001-FD004 profiles, lifecycle progression, fault onset caution, operating-condition effects, sensor noise, SHAP interpretation, CNN attention, model disagreement, low TTE, high uncertainty, UQ alarms, checkpoint history, critical focus, safe inspection language, evidence quality, metadata, query routing, retrieval tests, and output validation.

## How To Use

Use Failure Mode RAG after Domain and Metric RAG have established the current context and after Policy RAG has established action constraints. Failure Mode RAG supports explanation and inspection focus.

## Main Rule

Failure Mode RAG should explain possible degradation context without claiming unsupported physical diagnosis.

## How This Improves Recommendation Reliability

This improves reliability by making the collection navigable and by clearly defining its scope.

## Suggested Metadata Tags

- `master_index`
- `failure_mode_rag`
- `collection_overview`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
