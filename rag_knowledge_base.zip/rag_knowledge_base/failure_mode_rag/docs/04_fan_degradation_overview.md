# Fan Degradation Overview

## Purpose

This document explains fan degradation as part of the official dual-fault context in FD003 and FD004.

## CMAPSS Context

Fan degradation is part of the official two-fault-mode configuration for FD003 and FD004. It should be retrieved when the inference payload identifies FD003 or FD004, especially when the case has low predicted TTE, active UQ alarms, high uncertainty, or top model features indicating late-window degradation trends.

## Dual-Fault Meaning

Because fan degradation appears together with HPC degradation in FD003 and FD004, the recommendation system should not assume that one mode alone explains the model output. A safer explanation is that the current subset has dual-fault context and that inspection or diagnostic review should consider both fan and compressor degradation possibilities.

## Recommendation Use

If the recommendation is safety-first or conservative for an FD004 case, Failure Mode RAG can support wording such as: `Because FD004 combines six operating conditions with HPC and fan degradation context, the recommendation is conservative when uncertainty is high.`

## How This Improves Recommendation Reliability

This improves reliability by making FD003/FD004 explanations dual-fault aware and avoiding false single-cause claims.

## Suggested Metadata Tags

- `fan_degradation`
- `FD003`
- `FD004`
- `dual_fault`
- `safe_explanation`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
