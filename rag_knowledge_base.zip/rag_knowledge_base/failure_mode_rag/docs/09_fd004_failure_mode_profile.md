# FD004 Failure-Mode Profile

## Purpose

This document provides a detailed failure-mode profile for FD004.

## Subset Identity

FD004 contains six operating conditions and two official fault modes: HPC degradation and fan degradation. This makes FD004 the most complex CMAPSS subset for failure-mode interpretation.

## Why FD004 Requires Caution

FD004 combines operating-condition variation with dual-fault degradation context. A low-TTE FD004 case with active UQ alarm or wide uncertainty should be interpreted carefully because model outputs may reflect both degradation progression and condition-driven sensor variation.

## Recommendation Use

For FD004, the recommendation system should retrieve Domain RAG for subset complexity, Metric RAG for uncertainty, Policy RAG for action constraints, and Failure Mode RAG for HPC/fan degradation context. A safe explanation should say the case is consistent with the FD004 dual-fault context, not that a specific component failure has been physically confirmed.

## How This Improves Recommendation Reliability

This improves reliability by providing conservative, source-grounded interpretation for the most complex CMAPSS subset.

## Suggested Metadata Tags

- `FD004`
- `dual_fault`
- `six_conditions`
- `HPC_degradation`
- `fan_degradation`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
