# SHAP-to-Failure-Mode Interpretation

## Purpose

This document explains how SHAP values should be connected to failure-mode reasoning.

## SHAP Scope

SHAP explains how features influence the HGB model prediction. It does not prove physical causality. Negative SHAP values decrease predicted TTE and can support an explanation that a feature pushed the model toward shorter remaining life.

## Safe Failure-Mode Use

If top SHAP features are trend-related, the system may say they support model-detected degradation behavior. If the case belongs to FD001 or FD002, this can be discussed in the context of HPC degradation. If the case belongs to FD003 or FD004, it should be discussed in dual-fault context.

## Unsafe Use

Do not claim that a SHAP feature proves compressor degradation or fan degradation unless the feature has a verified physical mapping and the failure-mode evidence supports the claim.

## How This Improves Recommendation Reliability

This improves reliability by using SHAP for transparent model reasoning without hallucinating root cause.

## Suggested Metadata Tags

- `SHAP`
- `failure_mode`
- `feature_importance`
- `causality_boundary`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
