# Degradation Progression and Lifecycle Interpretation

## Purpose

This document explains how degradation progression should be interpreted across an engine trajectory.

## Trajectory-Based Degradation

CMAPSS trajectories begin in normal operation and progress toward failure in training runs. The model predicts remaining cycles from a window of observed history. Therefore, failure-mode interpretation should consider lifecycle stage and not just one row.

## Early, Mid, Late, and Critical Stages

Early-life cases usually have high predicted TTE and weak degradation evidence. Mid-life and caution cases may show moderate risk or trend evidence. Late-life and critical cases have low predicted TTE, low uncertainty lower bounds, or active alarms, making failure-mode context more important for recommendations.

## Recommendation Use

Failure Mode RAG should support action explanations more strongly when the case is Warning or Critical, when UQ alarm is active, or when SHAP/CNN attention indicates recent degradation-relevant behavior.

## How This Improves Recommendation Reliability

This improves reliability by tying failure-mode explanation to temporal degradation rather than isolated sensor values.

## Suggested Metadata Tags

- `degradation_progression`
- `lifecycle`
- `critical_stage`
- `trajectory`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
