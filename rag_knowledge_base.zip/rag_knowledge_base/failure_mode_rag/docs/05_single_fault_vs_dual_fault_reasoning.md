# Single-Fault vs Dual-Fault Reasoning

## Purpose

This document explains how the recommendation system should reason differently for single-fault and dual-fault CMAPSS subsets.

## Single-Fault Subsets

FD001 and FD002 are single-fault-mode subsets. For these subsets, the official degradation context is HPC degradation. Failure-mode explanations can be more focused, but the system still should not claim exact component causality from generic sensor channels alone.

## Dual-Fault Subsets

FD003 and FD004 are dual-fault-mode subsets involving HPC degradation and fan degradation. A dual-fault setting can create more complex degradation behavior, especially when paired with multiple operating conditions in FD004. For these cases, failure-mode evidence should remain broader and acknowledge ambiguity.

## Effect on Recommendation

When uncertainty is high in a dual-fault subset, conservative recommendations are easier to justify because failure-mode attribution is less straightforward. This does not mean FD003/FD004 are always high risk; it means that when risk signals exist, explanation should mention dual-fault complexity.

## How This Improves Recommendation Reliability

This improves reliability by aligning failure-mode explanation strength with subset complexity.

## Suggested Metadata Tags

- `single_fault`
- `dual_fault`
- `FD001`
- `FD004`
- `failure_mode_reasoning`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
