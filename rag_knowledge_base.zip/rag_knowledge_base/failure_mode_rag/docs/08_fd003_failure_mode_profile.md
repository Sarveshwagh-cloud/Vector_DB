# FD003 Failure-Mode Profile

## Purpose

This document provides a detailed failure-mode profile for FD003.

## Subset Identity

FD003 contains one operating condition and two official fault modes: HPC degradation and fan degradation. The operating condition is simple, but the fault-mode context is more complex than FD001.

## Interpretation

For FD003, failure-mode evidence should retrieve both HPC and fan degradation context. Because there is one operating condition, sensor variation may be easier to compare than in FD004, but dual-fault ambiguity remains.

## Recommendation Use

If predicted TTE is low in FD003, the final explanation can say that the current case belongs to a dual-fault CMAPSS subset and that inspection focus should consider both compressor and fan degradation context. It should not claim which fault mode dominates unless evidence supports that.

## How This Improves Recommendation Reliability

This improves reliability by making FD003 explanations dual-fault aware without adding unnecessary operational-condition complexity.

## Suggested Metadata Tags

- `FD003`
- `HPC_degradation`
- `fan_degradation`
- `dual_fault`
- `single_condition`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
