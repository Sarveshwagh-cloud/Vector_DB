# Inspection Focus Recommendation Language

## Purpose

This document provides safe language for inspection-focused recommendations.

## Safe Language

Use phrases such as `inspection should focus on degradation evidence consistent with the official CMAPSS fault context` or `review fan and compressor degradation indicators for this dual-fault subset`.

## Avoid Overclaiming

Avoid phrases like `the fan has failed` or `sensor s11 proves HPC degradation` unless verified by additional evidence outside the standard CMAPSS generic sensor columns.

## Action Integration

Failure Mode RAG should support actions like inspection, expert review, and maintenance planning by explaining where attention should be directed, not by asserting certified diagnosis.

## How This Improves Recommendation Reliability

This improves reliability by giving the LLM safe phrasing for failure-mode-related recommendations.

## Suggested Metadata Tags

- `inspection_focus`
- `safe_language`
- `avoid_overclaiming`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
