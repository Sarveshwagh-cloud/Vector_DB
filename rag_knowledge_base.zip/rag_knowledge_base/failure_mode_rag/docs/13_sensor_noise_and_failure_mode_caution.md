# Sensor Noise and Failure-Mode Caution

## Purpose

This document explains how sensor noise should affect failure-mode reasoning.

## Noise Context

CMAPSS data is contaminated with sensor noise. Noise means that isolated spikes or small changes in sensor-derived features should not be treated as direct fault evidence.

## Trend vs Spike

Sustained trends, late-window changes, or repeated checkpoint behavior are more useful for failure-mode explanation than isolated noisy readings. Even then, they remain model evidence, not physical proof.

## Recommendation Use

When SHAP identifies a sensor-derived feature, final explanations should avoid saying the sensor proves a component fault. A safer phrase is: `The model used sensor-derived trend evidence that is consistent with degradation progression in this CMAPSS subset.`

## How This Improves Recommendation Reliability

This improves reliability by preventing sensor-noise overinterpretation.

## Suggested Metadata Tags

- `sensor_noise`
- `trend`
- `spike`
- `safe_explanation`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
