# Failure Mode Evidence Quality Criteria

## Purpose

This document defines how to judge whether retrieved failure-mode evidence is good enough.

## Strong Evidence

Strong failure-mode evidence matches the CMAPSS subset, mentions the correct official fault modes, acknowledges uncertainty limits, and aligns with model outputs such as low TTE, UQ alarm, SHAP trend evidence, or checkpoint progression.

## Weak Evidence

Weak evidence is generic machine-failure text, unrelated fault modes, unsupported sensor-to-component mapping, or failure-mode claims that ignore subset context.

## Evidence Quality Output

The Evidence Quality Checker should record whether failure-mode evidence is subset-matched, fault-mode-matched, and safe-language compliant.

## How This Improves Recommendation Reliability

This improves reliability by ensuring failure-mode explanations are relevant, grounded, and not hallucinated.

## Suggested Metadata Tags

- `evidence_quality`
- `failure_mode_match`
- `subset_match`
- `safe_language`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
