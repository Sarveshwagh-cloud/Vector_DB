# UQ Alarm Failure-Mode Interpretation

## Purpose

This document explains how UQ alarms should be interpreted in failure-mode explanations.

## UQ Alarm Meaning

A UQ alarm indicates that the uncertainty lower bound crossed an alarm threshold. It means conservative remaining-life estimates may be risky.

## Failure-Mode Meaning

UQ alarm does not identify a fault mode. It strengthens the case for conservative action and inspection, especially when combined with low predicted TTE or subset complexity.

## Recommendation Use

When UQ alarm is active, failure-mode explanation should focus on what should be inspected or reviewed, while Policy RAG decides whether normal operation is blocked.

## How This Improves Recommendation Reliability

This improves reliability by separating uncertainty risk from physical diagnosis.

## Suggested Metadata Tags

- `uq_alarm`
- `failure_mode`
- `inspection_focus`
- `conservative`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
