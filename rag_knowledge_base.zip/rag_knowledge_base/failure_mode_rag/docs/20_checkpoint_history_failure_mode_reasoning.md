# Checkpoint History Failure-Mode Reasoning

## Purpose

This document explains how checkpoint-history predictions should support failure-mode reasoning.

## Checkpoint History

Checkpoint-history inference provides predictions at multiple cutoffs for the same engine. This can show how predicted TTE and risk evolve as the trajectory progresses.

## Trend Evidence

If predicted TTE decreases across checkpoints or UQ alarms appear later in the trajectory, this supports a degradation progression explanation. It does not identify exact fault onset unless a validated onset method exists.

## Recommendation Use

For worsening checkpoint history, recommendations can mention progressive degradation evidence and support stronger monitoring or inspection actions.

## How This Improves Recommendation Reliability

This improves reliability by using temporal consistency rather than one isolated prediction.

## Suggested Metadata Tags

- `checkpoint_history`
- `trajectory`
- `degradation_progression`
- `RTC`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
