# FD002 Failure-Mode Profile

## Purpose

This document provides a detailed failure-mode profile for FD002.

## Subset Identity

FD002 contains six operating conditions and one official fault mode: HPC degradation. This means failure-mode context is focused on HPC degradation, but sensor interpretation is more complex than FD001 because operating conditions vary.

## Operational-Condition Complexity

In FD002, a sensor trend may reflect operating regime changes, degradation progression, or both. Therefore, failure-mode explanations should mention that multi-condition behavior can complicate interpretation. Similar cases should ideally be filtered by subset and operational context if available.

## Recommendation Use

For a risky FD002 case, the system can say that the official fault context is HPC degradation and that multi-condition variability increases the need for uncertainty-aware interpretation. If confidence is low or UQ alarm is active, conservative action is more defensible.

## How This Improves Recommendation Reliability

This improves reliability by combining official HPC degradation context with operating-condition caution.

## Suggested Metadata Tags

- `FD002`
- `HPC_degradation`
- `six_conditions`
- `operational_complexity`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
