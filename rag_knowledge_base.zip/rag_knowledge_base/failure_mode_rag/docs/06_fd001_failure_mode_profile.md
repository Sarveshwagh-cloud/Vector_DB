# FD001 Failure-Mode Profile

## Purpose

This document provides a detailed failure-mode profile for FD001.

## Subset Identity

FD001 contains one operating condition and one official fault mode: HPC degradation. This makes FD001 the least complex failure-mode setting among the four CMAPSS subsets.

## Interpretation

When the current case is FD001, Failure Mode RAG should emphasize single-condition HPC degradation. If predicted TTE is Safe and UQ alarm is false, failure-mode evidence can remain light. If predicted TTE is Critical or Warning, the explanation should connect the low remaining life to progression in the simulated HPC-degradation context.

## Recommended Wording

A reliable explanation might say: `This FD001 case belongs to a single-condition HPC-degradation subset. The low predicted TTE indicates the trajectory may be late in the simulated degradation process. The recommendation therefore prioritizes inspection or maintenance planning according to policy.`

## How This Improves Recommendation Reliability

This improves reliability by giving FD001-specific context instead of generic turbofan failure wording.

## Suggested Metadata Tags

- `FD001`
- `HPC_degradation`
- `single_condition`
- `single_fault`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
