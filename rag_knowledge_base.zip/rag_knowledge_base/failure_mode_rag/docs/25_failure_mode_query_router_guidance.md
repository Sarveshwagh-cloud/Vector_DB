# Failure Mode RAG Query Router Guidance

## Purpose

This document explains how the Query Router should query Failure Mode RAG.

## When to Query

Failure Mode RAG should be queried when predicted TTE is Warning or Critical, UQ alarm is active, confidence is Low, SHAP top features indicate degradation trend, CNN attention focuses on recent behavior, or the subset is FD003/FD004.

## Query Inputs

Use subset, risk zone, UQ alarm, confidence, top SHAP feature names, chart summaries, checkpoint trend, and model disagreement.

## Example Query

For FD004: `Find CMAPSS failure-mode context for FD004 low TTE, active UQ alarm, dual fault modes, possible HPC and fan degradation, and recent sequence attention.`

## Retrieval Style

Use balanced dense + sparse retrieval because both semantic context and exact terms like HPC, fan degradation, FD004, SHAP, and UQ alarm matter.

## How This Improves Recommendation Reliability

This improves reliability by ensuring failure-mode retrieval is driven by current inference evidence, not generic failure terms.

## Suggested Metadata Tags

- `query_router`
- `failure_mode_query`
- `FD004`
- `SHAP`
- `UQ_alarm`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
