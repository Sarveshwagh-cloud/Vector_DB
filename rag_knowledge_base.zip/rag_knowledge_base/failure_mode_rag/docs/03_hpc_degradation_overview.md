# High Pressure Compressor Degradation Overview

## Purpose

This document explains High Pressure Compressor degradation as the main official fault mode in FD001 and FD002 and as one of the two fault modes in FD003 and FD004.

## CMAPSS Context

High Pressure Compressor degradation is the official single fault mode for FD001 and FD002. It is also present in FD003 and FD004, where it appears alongside fan degradation. In the CMAPSS setting, this should be treated as a dataset-level fault-mode context, not as a proven physical diagnosis for every individual sample.

## Interpretation for Recommendations

If a current inference case belongs to FD001 or FD002 and predicted TTE is low, the failure-mode explanation should focus on HPC degradation context. The recommendation should not say that a specific physical compressor part has failed unless additional evidence supports that claim. It should say that the case is in a subset whose official degradation mode is HPC degradation and that low TTE suggests advanced progression in that simulated fault context.

## Connection to Model Evidence

SHAP top features, interval width, UQ alarm, and CNN attention can strengthen the explanation that the model sees degradation-related behavior. However, they explain the model's decision process rather than direct physical root cause. A safe final explanation might say: `The case belongs to an HPC-degradation subset, and the model predicts low TTE with uncertainty-aware risk; therefore inspection should focus on compressor-related degradation evidence.`

## How This Improves Recommendation Reliability

This improves reliability by allowing the recommendation system to discuss HPC degradation when appropriate without overclaiming physical diagnosis.

## Suggested Metadata Tags

- `HPC_degradation`
- `FD001`
- `FD002`
- `compressor_context`
- `safe_explanation`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
