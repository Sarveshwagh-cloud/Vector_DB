# CNN Attention to Degradation Timing

## Purpose

This document explains how CNN attention summaries should support failure-mode reasoning.

## Attention Scope

CNN attention indicates which time steps in the input window the sequence model emphasized. It is an explanation signal, not physical proof of a failure mode.

## Recent Attention

If attention is concentrated near the end of the window, the model may be using recent behavior strongly. In a low-TTE case, this can support a statement that recent trajectory behavior influenced the prediction.

## Distributed Attention

If attention is spread across the window, the model may rely on broader temporal context. This can support a less localized degradation explanation.

## Recommendation Use

Attention summaries can help explain why a sequence model contributed to a warning or critical estimate, but policy and UQ still decide action strength.

## How This Improves Recommendation Reliability

This improves reliability by making sequence-model explanations useful but bounded.

## Suggested Metadata Tags

- `CNN_attention`
- `degradation_timing`
- `sequence_model`
- `safe_explanation`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
