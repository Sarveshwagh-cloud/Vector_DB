# Failure Mode RAG Master Overview

## Purpose

This document defines the purpose of Failure Mode RAG for the CMAPSS recommendation system. It explains what this collection should and should not do, and how it supports recommendation generation without inventing unverified physical diagnoses.

## Role of Failure Mode RAG

Failure Mode RAG explains possible degradation context for the current engine case. For CMAPSS, this collection should focus on the fault modes explicitly associated with the dataset subsets: High Pressure Compressor degradation and fan degradation. It should also explain single-fault versus dual-fault behavior, operational-condition complexity, sensor-trend caution, SHAP-to-failure-mode boundaries, and CNN-attention timing interpretation.

The goal is not to provide certified aircraft troubleshooting instructions. The goal is to help the recommendation system say what degradation context is relevant, why a case may require inspection focus, and where uncertainty prevents strong physical claims.

## Authority Boundary

Failure Mode RAG is supporting evidence. It can help explain why a low-TTE case may be associated with HPC/fan degradation context, but it should not override Policy RAG. If Policy RAG says immediate inspection is required, Failure Mode RAG can explain likely inspection focus. If Failure Mode RAG says evidence is ambiguous, Policy RAG still controls action boundaries.

## No Unsupported Sensor Mapping

The public CMAPSS dataset describes generic sensor measurement columns. Unless your project stores a verified mapping for each sensor channel, Failure Mode RAG should not claim that a specific `s11` or `s7` sensor proves a specific component failure. It may safely refer to sensor-derived trends, slopes, deltas, late-window changes, and sequence-attention patterns as model evidence, not direct physical proof.

## How This Improves Recommendation Reliability

Failure Mode RAG improves reliability by grounding degradation explanations in the official CMAPSS fault-mode structure and by preventing the LLM from hallucinating unrelated machinery faults or exact sensor-to-component diagnoses.

## Suggested Metadata Tags

- `failure_mode_rag`
- `overview`
- `HPC_degradation`
- `fan_degradation`
- `no_false_mapping`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
