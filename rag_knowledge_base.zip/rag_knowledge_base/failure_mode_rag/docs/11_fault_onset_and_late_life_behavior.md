# Fault Onset and Late-Life Behavior

## Purpose

This document explains how fault onset and late-life behavior should be discussed in CMAPSS recommendations.

## Fault Onset in CMAPSS

The dataset description says engines operate normally at the start and develop a fault at some point. The exact fault onset time is not directly provided in the standard dataset files. Therefore, the system should not claim a precise onset cycle unless derived by a validated method.

## Late-Life Behavior

Low predicted TTE, rapidly declining checkpoint predictions, active UQ alarms, or risk-zone transitions can indicate that the current observed window may be late in the simulated degradation process.

## Safe Explanation

Use language such as `the model output suggests possible late-life degradation behavior` rather than `the fault began at cycle X`, unless a specific validated onset detector is part of the pipeline.

## How This Improves Recommendation Reliability

This improves reliability by preventing invented fault-onset claims while still allowing late-life degradation reasoning.

## Suggested Metadata Tags

- `fault_onset`
- `late_life`
- `checkpoint_history`
- `safe_language`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
