# Model Disagreement and Failure-Mode Ambiguity

## Purpose

This document explains how model disagreement should affect failure-mode claims.

## Disagreement Meaning

If the HGB and CNN predictions differ substantially, the system should treat failure-mode interpretation as less certain. One model may focus on engineered summaries while the other focuses on sequence patterns.

## Failure-Mode Impact

High model disagreement should reduce confidence in strong physical explanations. It does not necessarily mean the case is safe or unsafe, but it means the explanation should be cautious.

## Recommendation Use

For high disagreement and low TTE, recommend expert review or conservative action according to policy. For high disagreement but Safe prediction, increase monitoring or include a model-disagreement warning if policy requires it.

## How This Improves Recommendation Reliability

This improves reliability by making physical explanations less overconfident when the model evidence itself is mixed.

## Suggested Metadata Tags

- `model_disagreement`
- `ambiguity`
- `expert_review`
- `failure_mode_uncertainty`

## Source Basis

This failure-mode document is grounded in the official CMAPSS subset descriptions, the PHM08 damage-propagation paper, the NASA C-MAPSS simulator context, and the user's CMAPSS inference workflow. The official CMAPSS Jet Engine Simulated Data page identifies FD001 and FD002 as one-fault-mode HPC degradation datasets, and FD003 and FD004 as two-fault-mode datasets involving HPC degradation and fan degradation. It also states that operational settings affect engine performance, sensor noise is present, and faults grow until failure in training trajectories. This document avoids unsupported mapping of individual generic sensor columns `s1` through `s21` to exact physical components unless such mapping is separately verified.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- nasa_cmapss_aircraft_engine_simulator_data: https://data.nasa.gov/dataset/c-mapss-aircraft-engine-simulator-data
- cmapss_user_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf

---
Collection: `failure_mode_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
