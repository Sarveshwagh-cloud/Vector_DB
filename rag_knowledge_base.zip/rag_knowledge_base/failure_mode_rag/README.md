# Failure Mode RAG v1: Deep CMAPSS Failure-Mode Collection

This package contains detailed Failure Mode RAG documents for the CMAPSS recommendation system.

## Contents
- 28 detailed markdown documents
- metadata.json
- failure_mode_rag_v1_summary.json

## Mapping
`rag_knowledge_base/failure_mode_rag/docs/` -> Qdrant collection `failure_mode_rag`

## Design Rules
1. Focus on official CMAPSS fault context: HPC degradation and fan degradation.
2. Do not include unrelated machine failure modes unless the project expands beyond CMAPSS.
3. Do not claim exact physical root cause from generic sensor IDs without verified mapping.
4. Failure Mode RAG supports explanation and inspection focus; Policy RAG controls action constraints.

## Recommended Retrieval
Use balanced dense+sparse hybrid retrieval because both semantic degradation context and exact terms such as `HPC`, `fan degradation`, `FD004`, `SHAP`, and `UQ alarm` matter.
