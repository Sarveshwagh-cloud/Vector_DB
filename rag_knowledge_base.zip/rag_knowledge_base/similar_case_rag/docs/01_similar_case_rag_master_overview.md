# Similar Case RAG Master Overview

## Purpose

This document defines the role of Similar Case RAG in the CMAPSS recommendation system. Similar Case RAG retrieves previous or generated case summaries that resemble the current inference case.

## What Similar Case RAG Should Store

Similar Case RAG should store summarized cases, not raw sensor rows. A good case summarizes one engine at one meaningful decision point: final observed cycle, checkpoint-history cycle, critical-focus cycle, top-error example, top-uncertain example, UQ-alarm example, or not-covered example. The case should include prediction values, actual TTE if available, uncertainty, risk zone, UQ alarms, model disagreement, top features, action recommendation, and outcome or lesson.

## Why Raw Rows Are Not Enough

A raw CMAPSS row contains unit, cycle, operating settings, and sensor values. That row does not explain why a recommendation was made. Similar Case RAG should store context-rich narratives and structured JSON that the retriever can compare semantically and with metadata filters.

## When Similar Cases Are Most Useful

Similar cases are especially useful for borderline cases, low-TTE cases, UQ-alarm cases, high-uncertainty cases, high-error cases, missed-critical cases, and safe-but-UQ-caution cases. They help the recommendation engine justify why a safety-first, conservative, balanced, or monitoring action is appropriate based on previous examples.

## How This Improves Recommendation Reliability

Similar Case RAG improves reliability by grounding recommendations in comparable prior model behavior and outcomes instead of relying only on abstract rules.

## Suggested Metadata Tags

- `similar_case_rag`
- `case_summary`
- `checkpoint_case`
- `retrieval`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
