# Similar Case Query Router Guidance

## Purpose

This document explains how the Query Router should create similar-case queries.

## Query Inputs

Use subset, unit if relevant, predicted_tte, lower_bound_95, risk_zone, UQ alarm, confidence, model disagreement, top features, sample_role, and actual_tte if available.

## Example Critical Query

`Find previous CMAPSS cases with predicted TTE below 30 cycles, active UQ alarm, Critical risk, and conservative recommendation outcome.`

## Example Safe UQ Caution Query

`Find cases where point risk was Safe but 95% lower bound created Possible Caution and monitoring was recommended.`

## Retrieval Strategy

Use metadata filtering first, then hybrid dense/sparse retrieval, then reranking. Similar Case RAG should not rely on vector similarity alone.

## How This Improves Recommendation Reliability

This improves reliability by ensuring current-case matching is structured and risk-aware.

## Suggested Metadata Tags

- `query_router`
- `similar_case_query`
- `metadata_filtering`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
