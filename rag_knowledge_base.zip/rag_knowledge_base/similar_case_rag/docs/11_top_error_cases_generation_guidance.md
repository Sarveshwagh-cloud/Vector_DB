# Top Error Cases Generation Guidance

## Purpose

This document explains how to turn top-error rows into similar cases.

## Definition

Top-error cases are cases with the largest absolute_error values. They reveal where the model struggled most.

## What to Store

Store actual_tte, predicted_tte, residual, absolute_error, coverage flags, confidence, interval width, risk zone correctness, and top feature explanations if available.

## Recommendation Lesson

Top-error cases should teach the recommendation system not to overtrust the model in similar conditions. If top-error cases share high uncertainty or model disagreement, future similar cases should trigger conservative wording.

## How This Improves Recommendation Reliability

This improves reliability by learning from model failure modes and not only successful predictions.

## Suggested Metadata Tags

- `top_errors`
- `absolute_error`
- `model_failure`
- `audit`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
