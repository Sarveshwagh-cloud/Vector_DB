# Similar Case Evidence Quality Criteria

## Purpose

This document defines how to evaluate retrieved similar-case evidence.

## Strong Case Evidence

Strong evidence matches dataset, asset type, subset or comparable complexity, TTE bucket, risk zone, UQ alarm status, confidence level, and outcome type.

## Weak Case Evidence

Weak evidence has mismatched risk zone, missing source, no outcome, no uncertainty fields, or is only a template being treated as historical proof.

## Conflict Handling

If similar cases conflict with Policy RAG, Policy RAG wins. Similar cases should support recommendations, not override hard constraints.

## How This Improves Recommendation Reliability

This improves reliability by preventing irrelevant cases from being overused.

## Suggested Metadata Tags

- `evidence_quality`
- `case_match`
- `conflict_resolution`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
