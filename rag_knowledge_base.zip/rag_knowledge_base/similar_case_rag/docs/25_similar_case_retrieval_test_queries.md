# Similar Case RAG Retrieval Test Queries

## Purpose

This document provides test queries for validating Similar Case RAG retrieval.

## Safe Case Query

Query: `Find safe checkpoint cases with predicted TTE above 90, false UQ alarms, and actual TTE covered by 95 interval.` Expected: unit 9 seed case and safe high-confidence pattern.

## Safe UQ Caution Query

Query: `Find safe point prediction but possible caution UQ case.` Expected: safe-but-UQ-caution pattern and supplied random sample with predicted TTE 103.0747.

## Critical Query

Query: `Find critical or UQ critical cases where normal operation should be blocked.` Expected: critical cases guidance and generated critical cases after ingestion.

## Top Error Query

Query: `Find high absolute error cases not covered by 95 interval.` Expected: top-error and not-covered case guidance; generated cases after CSV conversion.

## How This Improves Recommendation Reliability

This improves reliability by letting you test retrieval before using similar cases in final recommendations.

## Suggested Metadata Tags

- `retrieval_tests`
- `similar_case_rag`
- `validation_queries`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
