# Feedback to Similar Case Conversion

## Purpose

This document explains how future feedback logs should become new similar cases.

## Feedback Fields

A feedback log may include selected option, user feedback, actual action taken, actual outcome, actual TTE if known, and notes. If useful, it should be converted into a similar-case document.

## Conversion Rule

Only convert feedback into Similar Case RAG if it contains enough evidence to be useful: current prediction, action taken, outcome, and lesson. Low-quality feedback can remain in logs but should not pollute vector retrieval.

## Outcome Types

Useful outcomes include failure avoided, inspection confirmed degradation, no unplanned failure, false alarm, missed critical, technician override, and pending follow-up.

## How This Improves Recommendation Reliability

This improves reliability by allowing the system to learn from accepted recommendations and real outcomes over time.

## Suggested Metadata Tags

- `feedback`
- `case_conversion`
- `outcome`
- `continuous_learning`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
