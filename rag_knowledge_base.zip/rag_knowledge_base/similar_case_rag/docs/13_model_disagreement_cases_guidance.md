# Model Disagreement Similar Cases Guidance

## Purpose

This document explains how to create cases where boosting and CNN predictions disagree.

## Definition

A model-disagreement case has a large absolute difference between boost_pred and cnn_pred. This does not prove the ensemble is wrong, but it shows the base models interpret the input differently.

## What to Store

Store boost_pred, cnn_pred, ensemble_pred, disagreement magnitude, confidence, interval width, risk zone, UQ alarm, and final outcome.

## Recommendation Lesson

Similar high-disagreement cases should trigger model-disagreement warnings, expert review, or conservative scoring depending on risk and policy.

## How This Improves Recommendation Reliability

This improves reliability by making model uncertainty visible through previous examples.

## Suggested Metadata Tags

- `model_disagreement`
- `boost_pred`
- `cnn_pred`
- `ensemble`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
