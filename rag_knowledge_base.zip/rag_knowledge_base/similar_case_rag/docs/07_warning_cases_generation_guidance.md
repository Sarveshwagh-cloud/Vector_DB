# Warning Cases Generation Guidance

## Purpose

This document explains how to create and use warning cases.

## Definition

Warning cases usually have predicted TTE between 30 and 60 cycles or uncertainty lower bounds entering that range. These cases are not always immediate-emergency cases, but they usually require inspection or maintenance planning soon.

## What to Store

Store risk zone, UQ risk zone, confidence, interval width, action taken, and whether actual TTE confirmed the warning. If planned maintenance would be appropriate, include that lesson.

## Recommendation Lesson

Warning cases help the system choose between balanced, safety-first, and cost-optimized options. A typical lesson is that planned maintenance soon is often better than normal operation when TTE is in the warning range.

## How This Improves Recommendation Reliability

This improves reliability by helping the system avoid both overreaction and underreaction in mid-risk cases.

## Suggested Metadata Tags

- `warning_cases`
- `30_60_cycles`
- `planned_maintenance`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
