# Similar Case RAG Metadata Guidelines

## Purpose

This document defines metadata requirements for Similar Case RAG documents.

## Required Metadata

Each case should include collection_name, rag_type, case_id, source_file, generated_from, dataset, subset, asset_type, unit, sample_role, end_cycle, tte_bucket, risk_zone, uq_alarm_95, confidence, uncertainty_bucket, error_bucket, outcome_type, trust_level, source_priority, and version.

## Metadata Filtering

For retrieval, filter by dataset and asset_type first. Then prefer matching subset, tte_bucket, risk_zone, uq_alarm_95, confidence, and outcome_type.

## Trust Levels

User-provided or artifact-generated evaluation cases should have medium_high or high trust. Templates should have medium trust and should not be treated as actual outcomes.

## How This Improves Recommendation Reliability

This improves retrieval quality and prevents irrelevant cases from influencing recommendations.

## Suggested Metadata Tags

- `metadata`
- `case_id`
- `tte_bucket`
- `outcome_type`
- `Qdrant`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
