# Checkpoint History Similar Cases Guidance

## Purpose

This document explains how to create similar cases from checkpoint-history predictions.

## Definition

Checkpoint-history cases are multiple predictions for the same unit at different end cycles. They show how predicted TTE, risk zone, and UQ risk evolve over time.

## What to Store

Store unit, checkpoint index, end_cycle, window_start_cycle, predicted_tte, UQ bounds, risk zone, confidence, and trend summary from previous checkpoints.

## Recommendation Lesson

If TTE declines steadily or risk escalates across checkpoints, future similar cases can support progressive degradation wording and earlier intervention.

## How This Improves Recommendation Reliability

This improves reliability by using temporal progression instead of isolated predictions.

## Suggested Metadata Tags

- `checkpoint_history`
- `trajectory`
- `trend`
- `temporal_case`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
