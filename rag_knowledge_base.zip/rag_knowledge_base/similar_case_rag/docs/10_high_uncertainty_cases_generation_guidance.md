# High Uncertainty Cases Generation Guidance

## Purpose

This document explains how to create similar cases for high interval-width cases.

## Definition

High uncertainty cases have wide interval_width_90 or interval_width_95, low confidence, or large model disagreement. These cases may not be low TTE, but their predictions are less precise.

## What to Store

Store interval widths, confidence, model disagreement, UQ risk zone, and whether the actual TTE was covered. Include the recommendation lesson: expert review or conservative monitoring may be appropriate when uncertainty is high.

## Recommendation Use

High uncertainty cases help the system explain why it selected Conservative mode or added expert review even when point risk is not Critical.

## How This Improves Recommendation Reliability

This improves reliability by making uncertainty a first-class retrieval signal.

## Suggested Metadata Tags

- `high_uncertainty`
- `interval_width_95`
- `low_confidence`
- `expert_review`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
