# Not Covered Interval Cases Guidance

## Purpose

This document explains how to create cases where actual TTE falls outside the uncertainty interval.

## Definition

A not-covered case is one where actual TTE is outside the 90% or 95% interval. These cases are especially important for UQ calibration and trust.

## What to Store

Store whether covered_90 and covered_95 are false, interval bounds, predicted_tte, actual_tte, residual, interval width, and whether the miss was above or below the interval.

## Recommendation Lesson

Not-covered cases teach the system that uncertainty intervals are useful but imperfect. In similar future cases, final answers should mention uncertainty limitation or add expert review if risk is high.

## How This Improves Recommendation Reliability

This improves reliability by preventing overconfidence in uncertainty intervals.

## Suggested Metadata Tags

- `not_covered_95`
- `coverage`
- `calibration`
- `uncertainty_limit`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
