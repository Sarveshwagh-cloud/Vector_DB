# Similar Case RAG Master Index

## Purpose

This document summarizes the Similar Case RAG collection.

## Included Topics

This collection covers case generation sources, case types, schema, metadata filtering, critical cases, warning cases, caution/safe cases, UQ alarm cases, high uncertainty, top errors, not-covered cases, model disagreement, checkpoint history, critical focus, safe UQ caution, safe high-confidence cases, narrative templates, feedback conversion, authenticity, query routing, evidence quality, output validation, and retrieval tests.

## How To Use

Use Similar Case RAG after the current inference payload is available and after Query Router creates risk-aware case queries. Retrieved cases should support action explanation and option scoring.

## Main Rule

Similar cases are supporting evidence. They should not override Policy RAG or invent outcomes.

## How This Improves Recommendation Reliability

This improves reliability by making the Similar Case collection navigable and auditable.

## Suggested Metadata Tags

- `master_index`
- `similar_case_rag`
- `collection_overview`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
