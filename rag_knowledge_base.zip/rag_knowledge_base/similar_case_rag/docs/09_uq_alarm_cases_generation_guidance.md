# UQ Alarm Case Generation Guidance

## Purpose

This document explains how to create and retrieve UQ-alarm similar cases.

## Definition

A UQ-alarm case has uq_alarm_90 or uq_alarm_95 active. The most important subtype is uq_alarm_95 because it uses the more conservative lower bound.

## What to Store

Store predicted_tte, lower_bound_95, uq_alarm_95, uq_risk_zone_95, point risk zone, confidence, and whether the alarm caught an actual critical case.

## Recommendation Lesson

UQ-alarm cases teach the system that point predictions can hide risk. If point risk is Safe or Caution but UQ risk is Possible Caution or Possible Critical, the final recommendation should mention uncertainty-aware caution.

## How This Improves Recommendation Reliability

This improves reliability by making uncertainty-aware cases retrievable and explainable.

## Suggested Metadata Tags

- `uq_alarm`
- `lower_bound_95`
- `possible_critical`
- `uncertainty`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
