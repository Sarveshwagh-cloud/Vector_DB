# Safe Point Prediction but UQ Caution Case Pattern

## Purpose

This document explains a common important pattern: point prediction is Safe, but UQ risk suggests caution.

## Pattern

The model point prediction may be Safe while the 95% lower bound places the case in Possible Caution. This happened in the user-provided UQ sample with actual TTE 97.0, predicted TTE 103.0747, lower_bound_95 78.5169, point risk Safe, and UQ risk Possible Caution.

## Recommendation Meaning

This pattern should not be treated as plain normal operation. A good recommendation is normal operation with increased monitoring or UQ-aware caution, depending on policy.

## Case Retrieval

When a current input has Safe point risk but lower_bound_95 below the caution threshold, retrieve this pattern and similar cases.

## How This Improves Recommendation Reliability

This improves reliability by ensuring UQ-aware caution is not lost when point prediction looks safe.

## Suggested Metadata Tags

- `safe_point`
- `uq_caution`
- `lower_bound_95`
- `monitoring`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
