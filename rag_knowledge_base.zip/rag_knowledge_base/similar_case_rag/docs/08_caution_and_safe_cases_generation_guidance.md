# Caution and Safe Cases Generation Guidance

## Purpose

This document explains how to create and use Caution and Safe cases.

## Caution Cases

Caution cases usually have predicted TTE between 60 and 90 cycles. They often support increased monitoring, planned inspection, or trend tracking rather than immediate maintenance.

## Safe Cases

Safe cases usually have predicted TTE above 90 cycles. If confidence is high or medium and UQ alarms are false, normal operation may be appropriate. However, safe point prediction with UQ risk Possible Caution should be stored as a special case type.

## Why Safe Cases Matter

Safe cases are important because they stop the recommendation system from always choosing conservative action. They provide evidence for when normal operation with monitoring is reasonable.

## How This Improves Recommendation Reliability

This improves reliability by allowing the system to recommend proportionate actions when risk is low.

## Suggested Metadata Tags

- `caution_cases`
- `safe_cases`
- `normal_operation`
- `monitoring`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
