# Critical Cases Generation Guidance

## Purpose

This document explains how to create and use critical similar cases.

## Definition

A critical case is one where predicted_tte is below 30 cycles or actual_tte is below 30 cycles when target exists. Critical cases are the most important for safety because they test whether the system catches near-failure states.

## What to Store

Store the predicted TTE, actual TTE, lower_bound_95, UQ alarm, confidence, action recommendation, whether the case was correctly classified, and whether decision alarms caught the case. Include top features and chart summaries if available.

## Recommendation Lesson

Critical cases should teach the system that normal operation is not appropriate when point risk or UQ-aware risk indicates near-term failure. If a case was missed by point prediction but caught by UQ alarm, mark it as `uq_alarm_helped`.

## How This Improves Recommendation Reliability

This improves reliability by reducing the chance of missed critical failures in final recommendations.

## Suggested Metadata Tags

- `critical_cases`
- `below_30_cycles`
- `CFMR`
- `safety`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
