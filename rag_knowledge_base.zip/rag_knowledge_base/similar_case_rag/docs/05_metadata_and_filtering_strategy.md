# Metadata and Filtering Strategy for Similar Cases

## Purpose

This document explains how metadata should be used to retrieve relevant similar cases.

## Core Metadata

Important metadata fields include subset, unit, sample_role, risk_zone, uq_alarm_95, confidence, tte_bucket, actual_zone, risk_zone_correct, covered_95, error_bucket, uncertainty_bucket, model_disagreement_bucket, and outcome_type.

## Filter First, Vector Search Second

For Similar Case RAG, metadata filtering should be stronger than in Domain RAG. A semantically similar case with a different risk zone or UQ alarm status may mislead the recommendation. Filter by dataset, asset_type, subset if available, risk zone or TTE bucket, and UQ alarm status before reranking.

## TTE Buckets

Recommended buckets: below_30_cycles, 30_60_cycles, 60_90_cycles, 90_plus_cycles. These align with your project risk thresholds and support risk-aware retrieval.

## Outcome Buckets

Recommended outcome_type values: critical_caught, critical_missed, uq_alarm_helped, high_error, not_covered_95, safe_high_confidence, safe_uq_caution, warning_planned_maintenance, pending_feedback.

## How This Improves Recommendation Reliability

This improves reliability by ensuring retrieved cases are truly comparable to the current inference case.

## Suggested Metadata Tags

- `metadata`
- `filtering`
- `tte_bucket`
- `outcome_type`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
