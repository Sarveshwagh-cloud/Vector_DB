# Similar Case Schema Required Fields

## Purpose

This document defines the minimum structured fields required for each similar-case document.

## Identity Fields

Each case should include case_id, dataset, subset if known, asset_type, unit, sample_role, end_cycle, window_start_cycle if available, and source_artifact.

## Prediction Fields

Each case should include predicted_tte, boost_pred, cnn_pred, ensemble_pred, model_disagreement_abs, conformal_q90, conformal_q95, lower_bound_90, upper_bound_90, lower_bound_95, upper_bound_95, interval_width_90, interval_width_95, confidence, risk_zone, and predicted_zone.

## Decision and Outcome Fields

Each case should include recommendation, uq_recommendation_90, uq_recommendation_95, critical_alarm_30, critical_alarm_33, uq_alarm_90, uq_alarm_95, uq_risk_zone_90, uq_risk_zone_95, actual_tte if available, actual_zone if available, residual if available, absolute_error if available, coverage flags, action_taken, outcome, and recommendation_lesson.

## Evidence Fields

Each case should include source_ids or generated_from fields so the final system can trace whether the case came from evaluation output, feedback log, or manually curated seed case.

## How This Improves Recommendation Reliability

This improves reliability by making every retrieved case comparable and auditable.

## Suggested Metadata Tags

- `case_schema`
- `required_fields`
- `metadata`
- `audit`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
