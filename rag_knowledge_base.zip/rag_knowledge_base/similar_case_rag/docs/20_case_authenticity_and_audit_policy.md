# Similar Case Authenticity and Audit Policy

## Purpose

This document explains how to prove that a similar case is authentic and not invented.

## Authentic Case Requirements

An authentic case should include generated_from, source_file, source_row_id or unit/cycle identifier, model_version, created_at, and whether ground truth was available.

## Seed and Template Labels

If a case is a template or archetype, it must be labeled as a template. If it is derived from a user-provided sample, it should be labeled as user_provided_seed_case. If it is generated from CSV/JSON artifacts, it should cite those artifacts.

## Final Recommendation Use

The LLM should not cite a case template as historical proof. It may cite it as a pattern definition. Actual generated cases with source artifacts can be cited as previous examples.

## How This Improves Recommendation Reliability

This improves authenticity by preventing synthetic or template cases from being misrepresented as historical outcomes.

## Suggested Metadata Tags

- `authenticity`
- `audit`
- `source_file`
- `seed_case`
- `template`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
