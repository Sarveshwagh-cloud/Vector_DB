# Similar Case Output Validator Rules

## Purpose

This document defines validation rules for using similar cases in final recommendations.

## No Template as Historical Proof

The output validator should flag any final answer that cites a template/archetype as if it were an actual historical case.

## Source IDs Required

Every cited similar case should include case_id, source_file, and generated_from.

## No Outcome Invention

If outcome is unknown or pending, the final answer must not claim failure was avoided or degradation was confirmed.

## Policy Boundary

A similar case cannot justify an action blocked by Policy RAG.

## How This Improves Recommendation Reliability

This improves authenticity and prevents misuse of case evidence.

## Suggested Metadata Tags

- `output_validator`
- `similar_case`
- `no_invention`
- `case_citation`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
