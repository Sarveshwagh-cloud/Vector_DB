# Critical Focus Similar Cases Guidance

## Purpose

This document explains how to create similar cases from critical-focus inference samples.

## Definition

Critical-focus samples are intentionally selected near or inside risk-critical regions when target information is available, or near latest observed cycles when not. They are useful for stress-testing recommendation behavior.

## What to Store

Store why the case was selected, whether it was near the critical threshold, what the model predicted, whether UQ alarm was active, and what action would be appropriate.

## Recommendation Lesson

Critical-focus cases should teach the system how to behave around risk thresholds and uncertainty boundaries.

## How This Improves Recommendation Reliability

This improves reliability by testing and retrieving cases that are most important for safety.

## Suggested Metadata Tags

- `critical_focus`
- `threshold_case`
- `safety_testing`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
