# Case Generation Sources

## Purpose

This document explains where similar cases should come from in your CMAPSS pipeline.

## Primary Sources

The best sources are your own saved inference and evaluation artifacts: recommendation-ready predictions, final inference JSON, test UQ predictions, critical-case tables, top-error tables, top-uncertain tables, coverage-details tables, not-covered-95 tables, risk-count tables, UQ-risk-count tables, and checkpoint-history outputs.

## Evaluation Cases vs Deployment Cases

Evaluation cases can include actual_tte, residual, absolute_error, covered_90, covered_95, actual_zone, risk_zone_correct, and outcome labels because ground truth is available. Deployment cases may not have actual TTE, so they should be logged as pending-outcome cases until feedback or later ground truth becomes available.

## Seed Cases

For the first vector DB build, include a small number of seed cases from the user-provided random samples and case archetypes. Later, automatically generate hundreds or thousands of cases from your CSV/JSON artifacts.

## How This Improves Recommendation Reliability

This improves reliability by making sure Similar Case RAG grows from actual model outputs and feedback rather than invented examples.

## Suggested Metadata Tags

- `case_generation`
- `inference_outputs`
- `evaluation_cases`
- `deployment_cases`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
