# Similar Case Narrative Template

## Purpose

This document provides the narrative style that each similar-case markdown or JSON text field should follow.

## Narrative Structure

A good case narrative should describe the current engine/unit context, prediction values, uncertainty values, risk interpretation, actual outcome if available, and recommendation lesson.

## Example Narrative Style

`This case comes from a CMAPSS checkpoint-history sample for unit 9. The ensemble predicted 115.5 cycles remaining, with a 95% interval from 91.0 to 125.0. Point and UQ-aware risk were Safe/Likely Safe, and the actual TTE was 124.0. The case was covered by both 90% and 95% intervals. The lesson is that normal operation is reasonable when point risk and UQ risk are both safe and confidence is acceptable.`

## Avoid Overclaiming

Do not describe a case as proving a physical component failure unless the case includes verified inspection outcome or confirmed failure-mode label.

## How This Improves Recommendation Reliability

This improves reliability by making cases understandable to the retriever, reranker, and final explanation layer.

## Suggested Metadata Tags

- `case_narrative`
- `template`
- `safe_language`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
