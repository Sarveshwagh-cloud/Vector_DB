# Case Types and Relevance Hierarchy

## Purpose

This document defines the best case types to include and how relevant they are during retrieval.

## Highest-Value Cases

The most valuable similar cases are critical cases, UQ-alarm cases, missed-critical or near-miss cases, not-covered interval cases, and high-error cases. These cases teach the recommendation engine where safety risk or model uncertainty is highest.

## Medium-Value Cases

Warning cases, safe-but-UQ-caution cases, high model-disagreement cases, and checkpoint cases are medium-value. They help tune trade-offs between monitoring, inspection, and maintenance planning.

## Baseline Cases

Safe high-confidence cases are still useful because they prevent the system from overreacting. They show when normal operation with routine or increased monitoring may be reasonable.

## Retrieval Priority

For risky current inputs, prioritize cases by matching risk level, UQ alarm status, TTE bucket, subset, confidence, and failure-mode context. For safe current inputs, prioritize safe cases with similar uncertainty and confidence.

## How This Improves Recommendation Reliability

This improves reliability by making retrieval intentionally risk-aware instead of only similarity-score based.

## Suggested Metadata Tags

- `case_types`
- `relevance_hierarchy`
- `critical_cases`
- `safe_cases`

## Source Basis

This Similar Case RAG document is grounded in the CMAPSS dataset structure, the user's inference pipeline outputs, the user's weighted ensemble UQ metrics, saved case tables, and the recommendation architecture. CMAPSS contains train/test engine trajectories and test RUL values, so similar cases should be generated as engine-level or checkpoint-level summaries rather than raw cycle rows. Seed examples that copy the user's supplied random samples are marked as user-provided examples. Case archetypes and templates are not claimed to be historical outcomes until generated from actual inference/evaluation artifacts.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, final inference samples, weighted ensemble UQ metrics, saved tables, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
