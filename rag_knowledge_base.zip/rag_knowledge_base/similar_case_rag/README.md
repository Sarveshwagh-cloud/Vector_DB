# Similar Case RAG v1: Deep CMAPSS Similar-Case Collection

This package contains detailed Similar Case RAG guidance documents plus seed cases and a full JSON case template.

## Contents
- 26 detailed guidance markdown documents
- 2 user-provided seed case JSON files
- 1 full case-template JSON file
- metadata.json
- similar_case_rag_v1_summary.json

## Mapping
`rag_knowledge_base/similar_case_rag/docs/` and `case_templates_and_seed_cases/` -> Qdrant collection `similar_case_rag`

## Important
- Seed cases are based on user-provided random sample outputs.
- Templates are not historical cases and must not be cited as outcomes.
- Future high-value cases should be generated from your saved prediction, critical-case, top-error, coverage, and feedback artifacts.
