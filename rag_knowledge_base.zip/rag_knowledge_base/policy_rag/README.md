# Policy RAG v1: Deep CMAPSS Policy Collection

This package contains project-defined Policy RAG documents for the CMAPSS recommendation system.

## Contents
- 30 detailed markdown documents
- metadata.json
- policy_rag_v1_summary.json

## Mapping
`rag_knowledge_base/policy_rag/docs/` -> Qdrant collection `policy_rag`

## Important
These policies are project-defined decision-support rules. They are not official NASA aircraft-maintenance policy.

## Retrieval
Policy RAG should use sparse-heavy hybrid retrieval because exact triggers such as `uq_alarm_95`, `predicted_tte < 30`, `confidence = Low`, and `risk_zone = Critical` matter.
