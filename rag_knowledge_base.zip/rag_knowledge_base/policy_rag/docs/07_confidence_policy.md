# Confidence Policy

## Purpose

This document defines action boundaries based on High, Medium, and Low confidence labels.

## High Confidence

High confidence means interval width is relatively narrow. Normal operation or monitoring can be allowed when risk is Safe and UQ alarm is false.

## Medium Confidence

Medium confidence should keep recommendations evidence-aware. For Warning or Caution cases, recommend increased monitoring, inspection planning, or maintenance scheduling depending on risk.

## Low Confidence

Low confidence should trigger expert review or conservative mode. Normal operation should not be selected as the only primary action when confidence is Low and any risk signal is present.

## Policy Boundary

Confidence is derived from interval width. It is not a guarantee that prediction is correct.

## How This Improves Recommendation Reliability

This improves reliability by making uncertain predictions trigger safer review behavior.

## Suggested Metadata Tags

- `confidence`
- `low_confidence`
- `expert_review`
- `conservative_policy`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
