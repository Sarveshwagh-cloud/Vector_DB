# Lower Bound 95 Policy

## Purpose

This document defines how the 95% lower bound should affect recommendation strength.

## Why Lower Bound Matters

The 95% lower bound is a conservative estimate of remaining life. It is important because point prediction may be safe while the lower bound indicates possible near-term risk.

## Critical Lower Bound

If lower_bound_95 < 30 or below the alarm threshold used by the project, recommend conservative action. Normal operation should be blocked if the lower bound indicates possible critical risk.

## Caution Lower Bound

If point prediction is Safe but lower_bound_95 places the case in Caution, the system should recommend increased monitoring or inspection planning instead of plain normal operation.

## Use in Scoring

Safety-first, risk-minimized, and conservative modes should strongly weight lower_bound_95. Cost-optimized mode may still consider lower disruption but must not ignore it.

## How This Improves Recommendation Reliability

This improves reliability by preventing optimistic point predictions from hiding uncertainty-driven risk.

## Suggested Metadata Tags

- `lower_bound_95`
- `conservative_risk`
- `UQ_policy`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
