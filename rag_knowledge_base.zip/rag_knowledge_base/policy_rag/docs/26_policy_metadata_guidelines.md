# Policy RAG Metadata Guidelines

## Purpose

This document defines metadata requirements for Policy RAG chunks.

## Required Metadata

Each policy chunk should include collection_name, rag_type, source_id, chunk_id, source_file, policy_name, policy_category, trigger_fields, required_action, blocked_actions, dataset, asset_type, trust_level, source_priority, and version.

## Source Priority

Policy RAG should usually use source_priority 1 because it controls hard action constraints.

## Filtering

If the current payload has uq_alarm_95 true, retrieve policies where trigger_fields include uq_alarm_95. If risk_zone is Critical, retrieve critical TTE policies.

## Example

Policy metadata for UQ alarm should include policy_name `UQ Alarm 95 Policy`, trigger_fields `[lower_bound_95, uq_alarm_95]`, required_action `[inspect_immediately_or_expert_review]`, and blocked_actions `[continue_normal_operation, monitoring_only]`.

## How This Improves Recommendation Reliability

This improves retrieval precision, source citation, and constraint traceability.

## Suggested Metadata Tags

- `metadata`
- `policy_name`
- `source_priority`
- `Qdrant`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
