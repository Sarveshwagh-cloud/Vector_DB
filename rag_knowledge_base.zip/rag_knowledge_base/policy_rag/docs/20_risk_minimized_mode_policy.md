# Risk-Minimized Mode Policy

## Purpose

This document defines policy boundaries for Risk-Minimized mode.

## Goal

Risk-minimized mode prioritizes reducing probability of missed failure and operational risk.

## Expected Behavior

For Critical or UQ-alarm cases, risk-minimized mode should select immediate maintenance or immediate inspection with maintenance preparation.

## Boundary

Risk-minimized mode may increase cost and downtime; this trade-off must be stated.

## How This Improves Recommendation Reliability

This improves reliability by making risk reduction explicit and auditable.

## Suggested Metadata Tags

- `risk_minimized`
- `risk_reduction`
- `immediate_maintenance`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
