# Critical Risk: No Normal Operation Policy

## Purpose

This document blocks normal operation under critical risk conditions.

## Blocked Action

If point predicted TTE is Critical, normal operation must be blocked as the primary recommendation.

## Also Block Weak Actions

Monitoring-only and continue-normal-operation actions should be blocked for Critical cases unless explicitly presented as temporary supporting actions after inspection or load reduction.

## Required Action Level

Critical cases should receive immediate inspection, immediate maintenance planning, expert review, or operational load reduction depending on UQ and confidence.

## Audit Requirement

The final output should record blocked actions and reasons.

## How This Improves Recommendation Reliability

This improves safety by ensuring the system cannot recommend weak actions for near-failure predictions.

## Suggested Metadata Tags

- `critical`
- `blocked_actions`
- `normal_operation`
- `safety_policy`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
