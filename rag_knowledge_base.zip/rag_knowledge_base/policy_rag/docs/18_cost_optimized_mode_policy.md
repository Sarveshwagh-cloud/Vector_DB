# Cost-Optimized Mode Policy

## Purpose

This document defines policy boundaries for Cost-Optimized mode.

## Goal

Cost-optimized mode reduces unnecessary maintenance cost while respecting safety constraints.

## Allowed Optimization

For Warning or Caution cases, cost-optimized mode can prefer planned inspection or scheduled maintenance during low-impact windows.

## Hard Boundary

Cost optimization must not override Critical risk, UQ alarm, low-confidence escalation, or policy blocks.

## Final Wording

The final report should say cost-optimized option has higher residual risk if it delays action compared with safety-first.

## How This Improves Recommendation Reliability

This improves reliability by allowing cost trade-offs only inside safe boundaries.

## Suggested Metadata Tags

- `cost_optimized`
- `cost`
- `TMC`
- `policy_boundary`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
