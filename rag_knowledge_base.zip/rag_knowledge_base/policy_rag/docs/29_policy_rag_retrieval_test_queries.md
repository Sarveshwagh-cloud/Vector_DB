# Policy RAG Retrieval Test Queries

## Purpose

This document gives test queries for validating Policy RAG retrieval.

## Critical Query

Query: `Policy for predicted_tte < 30 and Critical risk.` Expected: Critical Risk No Normal Operation Policy and TTE Threshold Policy.

## UQ Query

Query: `Policy for uq_alarm_95 true and lower_bound_95 below threshold.` Expected: UQ Alarm 95 Policy and Lower Bound 95 Policy.

## Confidence Query

Query: `Policy for Low confidence prediction and model disagreement.` Expected: Confidence Policy, Model Disagreement Policy, Expert Review Policy.

## Mode Query

Query: `Cost-optimized recommendation boundary under active UQ alarm.` Expected: Cost-Optimized Mode Policy and UQ Alarm 95 Policy.

## How This Improves Recommendation Reliability

This improves reliability by giving a clear retrieval test suite for the policy collection.

## Suggested Metadata Tags

- `retrieval_tests`
- `policy_rag`
- `validation_queries`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
