# Policy RAG Master Index

## Purpose

This document summarizes all Policy RAG documents and how they should be used.

## Included Policy Areas

The collection includes authority hierarchy, TTE thresholds, UQ alarms, lower bound policy, confidence policy, model disagreement, risk-specific action boundaries, data quality, evidence quality, candidate action boundaries, recommendation modes, expert review, load reduction, blocked actions, output validation, metadata, query routing, evidence quality, and retrieval tests.

## How To Use

Retrieve Policy RAG before candidate action filtering and before multi-objective scoring. Use it again during output validation.

## Main Rule

No final recommendation should violate Policy RAG.

## How This Improves Recommendation Reliability

This improves reliability by making the policy collection navigable and auditable.

## Suggested Metadata Tags

- `master_index`
- `policy_rag`
- `collection_overview`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
