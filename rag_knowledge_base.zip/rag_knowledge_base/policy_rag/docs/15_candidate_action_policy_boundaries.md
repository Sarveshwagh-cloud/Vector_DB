# Candidate Action Policy Boundaries

## Purpose

This document defines the action library boundaries used by the policy layer.

## Weak Actions

Continue normal operation, monitor routinely, or monitoring-only are weak actions. They are allowed only in Safe/Caution cases without active UQ alarms and with acceptable confidence.

## Moderate Actions

Increase monitoring frequency, inspect soon, and schedule maintenance soon are moderate actions suitable for Caution or Warning cases.

## Strong Actions

Inspect immediately, immediate maintenance required, reduce operating load, and expert review are strong actions used for Critical, UQ-alarm, low-confidence, or high-disagreement cases.

## Policy Output

Every action should be labeled allowed, restricted, or blocked with reason and source_id.

## How This Improves Recommendation Reliability

This improves reliability by making action generation controllable and auditable.

## Suggested Metadata Tags

- `candidate_actions`
- `allowed`
- `restricted`
- `blocked`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
