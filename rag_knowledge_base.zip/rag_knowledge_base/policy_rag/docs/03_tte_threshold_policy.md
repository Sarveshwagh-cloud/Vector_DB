# TTE Threshold Policy

## Purpose

This document defines project thresholds for predicted TTE risk zones and their recommended action boundaries.

## Risk Thresholds

Project-defined thresholds: Critical if predicted TTE < 30 cycles, Warning if predicted TTE < 60 cycles, Caution if predicted TTE < 90 cycles, Safe otherwise.

## Critical TTE Policy

If predicted TTE < 30, normal operation must be blocked as a primary recommendation. The system should recommend immediate inspection, maintenance planning, expert review, or stronger action depending on uncertainty and confidence.

## Warning TTE Policy

If 30 <= predicted TTE < 60, the system should recommend inspection soon or scheduled maintenance planning. Monitoring-only should be allowed only if confidence is high, UQ alarm is false, and policy evidence does not require escalation.

## Caution TTE Policy

If 60 <= predicted TTE < 90, increased monitoring or planned inspection can be appropriate. UQ lower bounds may still escalate the recommendation.

## Safe TTE Policy

If predicted TTE >= 90, normal operation may be allowed if UQ alarms are false and confidence is not low. If UQ risk indicates possible caution, monitoring should be increased.

## How This Improves Recommendation Reliability

This improves recommendation reliability by ensuring point-prediction risk zones lead to consistent baseline action boundaries.

## Suggested Metadata Tags

- `predicted_tte`
- `critical_threshold`
- `warning_threshold`
- `caution_threshold`
- `risk_zone`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
