# Policy RAG Query Router Guidance

## Purpose

This document explains how Query Router should create Policy RAG queries.

## Always Query Policy RAG

Policy RAG should be queried for every recommendation because every action must pass safety and constraint checks.

## Query Inputs

Use predicted_tte, risk_zone, lower_bound_95, uq_alarm_95, confidence, model disagreement, evidence quality, and selected recommendation mode.

## Example Queries

`Find policy for predicted TTE below 30 cycles.` `Find policy for uq_alarm_95 true and lower_bound_95 below alarm threshold.` `Find policy for low confidence and high model disagreement.`

## Retrieval Style

Policy RAG should use sparse-heavy hybrid retrieval and metadata filtering because exact triggers like uq_alarm_95 and predicted_tte < 30 matter.

## How This Improves Recommendation Reliability

This improves reliability by ensuring policy checks are driven by current inference fields.

## Suggested Metadata Tags

- `query_router`
- `policy_query`
- `sparse_heavy`
- `trigger_fields`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
