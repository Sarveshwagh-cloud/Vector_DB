# Safety-First Mode Policy

## Purpose

This document defines policy boundaries for Safety-First mode.

## Goal

Safety-first mode prioritizes avoiding missed critical failure risk over cost and downtime.

## Critical Behavior

If predicted TTE is critical or UQ alarm is active, safety-first should select inspection immediately, maintenance preparation, load reduction, or expert escalation.

## Boundary

Safety-first should never select normal operation for Critical or UQ-alarm cases.

## How This Improves Recommendation Reliability

This improves reliability by making the highest-safety recommendation clearly policy-aligned.

## Suggested Metadata Tags

- `safety_first`
- `critical`
- `inspection`
- `maintenance`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
