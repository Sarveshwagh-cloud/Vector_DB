# UQ Alarm 90 Policy

## Purpose

This document defines the action boundary when `uq_alarm_90` is active.

## Definition

`uq_alarm_90` uses the 90% lower bound. It is less conservative than the 95% alarm but still indicates possible risk.

## Policy Behavior

If `uq_alarm_90` is true and `uq_alarm_95` is false, the system should increase monitoring or recommend inspection soon depending on point risk and confidence.

## Escalation

If both `uq_alarm_90` and `uq_alarm_95` are true, follow the stronger 95% UQ alarm policy.

## Recommendation Boundary

Monitoring can remain an option for 90% UQ alarm cases only when point risk is not critical, confidence is high or medium, and no policy rule blocks it.

## How This Improves Recommendation Reliability

This improves reliability by creating a graduated uncertainty policy instead of treating all UQ alarms identically.

## Suggested Metadata Tags

- `uq_alarm_90`
- `lower_bound_90`
- `uncertainty_policy`
- `monitoring`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
