# Data Quality Policy

## Purpose

This document defines policy behavior when data quality signals are missing or weak.

## Current Status

If a numeric data_quality_score is not present, the final recommendation should not invent one.

## Missing Data Quality

If data quality is unknown, the system may state that explicit data quality scoring was not available.

## Low Data Quality Future Behavior

If a future data_quality_score exists and is low, require expert review or conservative recommendation.

## Preprocessing Compatibility

If preprocessing artifacts or required columns are missing, recommendation should be blocked until inference input is valid.

## How This Improves Recommendation Reliability

This improves reliability by preventing unsupported data-quality claims and by protecting against invalid inputs.

## Suggested Metadata Tags

- `data_quality`
- `input_validation`
- `future_metric`
- `expert_review`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
