# Model Disagreement Policy

## Purpose

This document defines how disagreement between boosting and CNN predictions should influence recommendations.

## Definition

Model disagreement is the difference between `boost_pred` and `cnn_pred`. Large disagreement indicates the two model families interpret the case differently.

## Warning Behavior

If model disagreement is high, add a model disagreement warning to the final report and consider expert review.

## Action Impact

High disagreement should reduce confidence alignment and increase conservative scoring, especially in Warning/Critical or UQ-alarm cases.

## Boundary

Model disagreement alone does not prove failure. It is a caution signal, not a physical root-cause signal.

## How This Improves Recommendation Reliability

This improves reliability by exposing model uncertainty beyond conformal interval width.

## Suggested Metadata Tags

- `model_disagreement`
- `boost_pred`
- `cnn_pred`
- `expert_review`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
