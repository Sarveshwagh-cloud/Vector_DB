# UQ Alarm 95 Policy

## Purpose

This document defines the action boundary when `uq_alarm_95` is active.

## Definition

`uq_alarm_95` is active when the 95% lower uncertainty bound crosses the project-defined alarm threshold. It means the conservative estimate of remaining life may be in a risky range.

## Hard Constraint

If `uq_alarm_95` is true, normal operation should not be selected as the primary recommendation. Monitoring-only should also be restricted unless an explicit expert override is recorded.

## Required Minimum Action

At minimum, recommend immediate inspection, expert review, load reduction with close monitoring, or maintenance planning depending on risk zone and confidence.

## Optimization Boundary

Cost-optimized and downtime-minimized modes must still respect UQ alarm policy. They can choose lower-disruption actions only inside the allowed safe boundary.

## How This Improves Recommendation Reliability

This improves reliability by making uncertainty-aware risk a hard constraint instead of a soft explanation.

## Suggested Metadata Tags

- `uq_alarm_95`
- `lower_bound_95`
- `hard_constraint`
- `uncertainty_policy`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
