# Conservative Mode Policy

## Purpose

This document defines policy boundaries for Conservative mode.

## When to Use

Use conservative mode when uncertainty is high, confidence is low, model disagreement is high, evidence quality is weak, or subset complexity is high.

## Expected Actions

Conservative mode should prefer expert review, immediate inspection, increased monitoring, load reduction, or maintenance planning.

## Boundary

Conservative mode should avoid weak recommendations unless all risk signals are low.

## How This Improves Recommendation Reliability

This improves reliability by providing a safe fallback when evidence or prediction confidence is limited.

## Suggested Metadata Tags

- `conservative`
- `low_confidence`
- `weak_evidence`
- `expert_review`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
