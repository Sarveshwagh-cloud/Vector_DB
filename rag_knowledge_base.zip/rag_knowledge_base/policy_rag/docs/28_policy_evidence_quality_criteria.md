# Policy Evidence Quality Criteria

## Purpose

This document defines how policy evidence quality should be checked.

## Strong Policy Evidence

Strong policy evidence directly matches the current trigger condition and states allowed, blocked, or required action boundaries.

## Weak Policy Evidence

Weak evidence is generic safety text without exact trigger fields or action boundary.

## Missing Policy Evidence

If policy evidence is missing for Critical or UQ-alarm cases, mark evidence weak and require expert review or conservative recommendation.

## Conflict Handling

If policies conflict, use the higher-priority safety/UQ policy and record the conflict.

## How This Improves Recommendation Reliability

This improves reliability by ensuring actions are supported by explicit policy evidence.

## Suggested Metadata Tags

- `evidence_quality`
- `policy_evidence`
- `conflict`
- `missing_policy`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
