# Warning Risk Policy

## Purpose

This document defines allowed and preferred actions for Warning risk.

## Preferred Actions

For Warning risk, preferred actions include inspect soon, schedule maintenance soon, increase monitoring frequency, or plan maintenance in the nearest feasible downtime window.

## Allowed Actions

Monitoring may be allowed if UQ alarm is false and confidence is high, but should not be the only recommendation when uncertainty is medium/low.

## Escalation

If lower_bound_95 is critical or UQ alarm is active, escalate to immediate inspection or stronger action.

## Scoring Boundary

Cost-optimized mode may choose planned maintenance soon, but not pure normal operation.

## How This Improves Recommendation Reliability

This improves reliability by making Warning risk actionable without always forcing emergency maintenance.

## Suggested Metadata Tags

- `warning`
- `inspect_soon`
- `schedule_maintenance`
- `risk_policy`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
