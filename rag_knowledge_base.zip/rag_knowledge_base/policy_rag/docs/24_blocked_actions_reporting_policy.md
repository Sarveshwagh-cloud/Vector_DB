# Blocked Actions Reporting Policy

## Purpose

This document defines how blocked actions should be recorded.

## Required Fields

Every blocked action should include action name, reason, triggering condition, supporting policy source_id, and timestamp or request_id.

## Examples

Continue normal operation blocked because predicted_tte < 30. Monitoring-only blocked because uq_alarm_95 is true. Cost-optimized delay blocked because confidence is Low and evidence is weak.

## Audit Use

Blocked action reporting is required for authenticity and reviewer trust.

## How This Improves Recommendation Reliability

This improves reliability by proving that unsafe options were considered and rejected, not silently ignored.

## Suggested Metadata Tags

- `blocked_actions`
- `audit`
- `policy_trace`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
