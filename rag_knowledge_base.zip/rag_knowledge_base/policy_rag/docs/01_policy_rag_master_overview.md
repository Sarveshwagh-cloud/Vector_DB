# Policy RAG Master Overview

## Purpose

This document defines the purpose of Policy RAG in the recommendation system. Policy RAG contains project-defined action constraints, escalation rules, threshold rules, and decision boundaries.

## Policy RAG Responsibility

Policy RAG decides what actions are allowed, restricted, blocked, or required. It is higher authority than Domain RAG, Metric RAG, Similar Case RAG, and Failure Mode RAG for action constraints.

## Not Official Maintenance Policy

These policies are project-defined for a CMAPSS simulated predictive-maintenance recommendation system. They must not be represented as certified aircraft maintenance rules.

## Core Principle

Safety and uncertainty-aware rules take priority over cost or downtime preferences. If the system detects critical point risk, UQ-aware possible critical risk, low confidence, or high model disagreement, recommendations should become more conservative.

## How This Improves Recommendation Reliability

Policy RAG improves reliability by preventing the system from selecting unsafe or unsupported actions even when another RAG branch or scoring mode suggests a weaker option.

## Suggested Metadata Tags

- `policy_rag`
- `overview`
- `authority`
- `constraints`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
