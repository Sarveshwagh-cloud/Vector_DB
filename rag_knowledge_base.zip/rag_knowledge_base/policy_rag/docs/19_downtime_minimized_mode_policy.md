# Downtime-Minimized Mode Policy

## Purpose

This document defines policy boundaries for Downtime-Minimized mode.

## Goal

Downtime-minimized mode reduces operational disruption while maintaining acceptable safety.

## Allowed Actions

Reduce load and monitor, inspect in nearest planned window, and increase monitoring may be allowed for non-critical cases.

## Hard Boundary

Downtime minimization cannot recommend continuing normal operation when predicted TTE is Critical or UQ alarm indicates possible critical risk.

## Risk Disclosure

The final recommendation should disclose higher residual risk when downtime is minimized.

## How This Improves Recommendation Reliability

This improves reliability by ensuring downtime reduction does not hide safety trade-offs.

## Suggested Metadata Tags

- `downtime_minimized`
- `downtime`
- `residual_risk`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
