# Caution Risk Policy

## Purpose

This document defines allowed and preferred actions for Caution risk.

## Preferred Actions

For Caution risk, increase monitoring frequency, inspect during next planned window, or schedule follow-up assessment.

## UQ Escalation

If UQ lower bound reaches Warning or Critical, follow the stronger UQ-aware policy.

## Confidence Boundary

If confidence is Low, add expert review or conservative monitoring rather than normal operation alone.

## Safe Boundary

If confidence is High and UQ alarms are false, normal operation with increased monitoring may be acceptable.

## How This Improves Recommendation Reliability

This improves reliability by avoiding both overreaction and underreaction for moderate-risk cases.

## Suggested Metadata Tags

- `caution`
- `monitoring`
- `inspection_planning`
- `risk_policy`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
