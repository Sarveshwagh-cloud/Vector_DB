# Safe Risk Policy

## Purpose

This document defines allowed actions for Safe risk.

## Normal Operation

For Safe point risk, normal operation may be allowed if UQ alarms are false, confidence is not low, and data/evidence quality is sufficient.

## UQ Caution

If point risk is Safe but UQ risk zone is Possible Caution, recommend normal operation with increased monitoring rather than plain normal operation.

## Low Confidence

If point risk is Safe but confidence is Low, recommend monitoring and expert review if other risk indicators exist.

## Boundary

Safe point risk does not automatically mean zero risk.

## How This Improves Recommendation Reliability

This improves reliability by allowing efficient operation while preserving UQ-aware caution.

## Suggested Metadata Tags

- `safe`
- `normal_operation`
- `uq_caution`
- `monitoring`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
