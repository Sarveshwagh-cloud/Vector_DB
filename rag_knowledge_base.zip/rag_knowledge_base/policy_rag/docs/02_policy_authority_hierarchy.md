# Policy Authority Hierarchy

## Purpose

This document defines the policy priority order used when multiple rules or evidence sources conflict.

## Recommended Priority Order

Use this hierarchy: 1. Safety policy, 2. UQ alarm policy, 3. Critical risk policy, 4. Confidence policy, 5. Model disagreement policy, 6. Evidence quality policy, 7. User preference or optimization mode, 8. LLM wording.

## Policy Overrides Other Evidence

If Similar Case RAG suggests monitoring but Policy RAG blocks monitoring-only action for an active UQ alarm, policy wins. If Domain RAG explains that FD004 is complex but Policy RAG requires inspection for critical risk, policy decides the action boundary.

## LLM Boundary

The LLM explanation layer must not override policy. It can explain policy-backed decisions but cannot create new rules or weaken hard constraints.

## How This Improves Recommendation Reliability

This improves reliability by making action selection deterministic and auditable when evidence sources disagree.

## Suggested Metadata Tags

- `authority_hierarchy`
- `policy_priority`
- `conflict_resolution`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
