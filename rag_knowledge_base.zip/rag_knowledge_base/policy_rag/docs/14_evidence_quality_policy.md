# Evidence Quality Policy

## Purpose

This document defines how weak, missing, or conflicting evidence affects recommendations.

## Sufficient Evidence

If Domain, Metric, and Policy evidence are sufficient, recommendation can proceed normally.

## Weak Evidence

If evidence is weak or missing, the final recommendation should include an evidence limitation and prefer conservative options for risky cases.

## Missing Policy Evidence

If policy evidence is missing for a critical or UQ-alarm case, do not allow weak recommendations. Escalate to expert review.

## Conflicting Evidence

If evidence conflicts, prefer higher-priority sources. Policy evidence overrides domain or similar-case evidence.

## How This Improves Recommendation Reliability

This improves reliability by preventing unsupported final recommendations when evidence retrieval is incomplete.

## Suggested Metadata Tags

- `evidence_quality`
- `missing_evidence`
- `conflict_resolution`
- `expert_review`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
