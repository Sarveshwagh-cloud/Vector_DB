# Reduce Load and Monitor Policy

## Purpose

This document defines when reducing operating load and monitoring is appropriate.

## Use Case

Reduce operating load and monitor can be an intermediate risk-control action when immediate shutdown/maintenance is not selected but uncertainty or risk is significant.

## Allowed Cases

It can be used for Warning, UQ caution, medium confidence, or high uncertainty cases as part of a broader action plan.

## Not Enough Alone

For Critical or active UQ critical cases, load reduction alone should not be the final primary action unless paired with immediate inspection or expert review.

## How This Improves Recommendation Reliability

This improves reliability by preventing load reduction from being used as a weak substitute for required inspection.

## Suggested Metadata Tags

- `load_reduction`
- `monitoring`
- `risk_control`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
