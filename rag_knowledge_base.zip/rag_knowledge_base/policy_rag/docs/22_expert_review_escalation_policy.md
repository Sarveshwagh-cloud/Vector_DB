# Expert Review Escalation Policy

## Purpose

This document defines when expert review should be required or recommended.

## Require Expert Review

Require or strongly recommend expert review when confidence is Low, model disagreement is high, evidence is weak/conflicting, input data quality is low, or UQ alarm is active with non-critical point prediction.

## Expert Review as Add-On

Expert review can be added to other actions such as inspect immediately or schedule maintenance soon.

## Final Output

The final answer should clearly state why expert review was added.

## How This Improves Recommendation Reliability

This improves reliability by routing uncertain or conflicting cases to human review instead of pretending full automation is enough.

## Suggested Metadata Tags

- `expert_review`
- `escalation`
- `low_confidence`
- `conflict`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
