# Policy Output Validation Rules

## Purpose

This document defines validation checks for policy-compliant final recommendations.

## Validation Checks

The output validator should verify: no blocked action is selected, sources are present, UQ alarm is not ignored, uncertainty is mentioned, prediction values are unchanged, trade-offs are included, and policy source IDs are cited.

## Fail Conditions

Fail if final answer recommends normal operation for Critical predicted TTE, omits active UQ alarm, invents policy, or cites missing source IDs.

## Pass Output

A pass means the final recommendation is structurally policy-compliant, not guaranteed perfect.

## How This Improves Recommendation Reliability

This improves reliability by adding a final safety gate before the recommendation is returned.

## Suggested Metadata Tags

- `output_validator`
- `policy_compliance`
- `validation`

## Source Basis

This policy document is project-defined for the CMAPSS recommendation system. It is based on the user-provided inference fields, project thresholds, UQ alarm logic, custom metrics, and recommendation architecture. It is not an official NASA aircraft-maintenance policy and must be presented as decision-support logic for a simulated predictive-maintenance benchmark.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- project_inference_outputs: User-provided inference outputs, UQ metrics, risk thresholds, and recommendation workflow design
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `policy_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
