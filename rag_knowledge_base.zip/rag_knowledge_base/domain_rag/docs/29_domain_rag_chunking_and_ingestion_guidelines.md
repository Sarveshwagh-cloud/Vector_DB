# Domain RAG Chunking and Ingestion Guidelines

## Purpose

This document explains how to chunk and ingest Domain RAG documents into Qdrant.

## Chunk Size

Domain documents should be chunked using section-aware splitting. A target chunk size of 300 to 700 words is appropriate, with 50 to 100 words overlap.

## Do Not Split Critical Context

Do not split an FD subset fact away from its recommendation implication. For example, `FD004 has six conditions and two fault modes` should remain near the explanation that FD004 is more complex.

## Metadata Per Chunk

Each chunk should inherit file-level metadata and get its own `chunk_id`. FD-specific chunks should include subset, operating condition count, fault mode count, and fault modes.

## Qdrant Collection

All chunks from this folder should be inserted into Qdrant collection `domain_rag` with dense and sparse embeddings.

## How This Helps Recommendation Reliability

This document improves reliability by preserving context during chunking and ensuring each retrieved passage is traceable and meaningful.

## Suggested Metadata Tags

- `chunking`
- `ingestion`
- `Qdrant`
- `BGE-M3`
- `metadata`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
