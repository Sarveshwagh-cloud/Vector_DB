# Sensor-Family Interpretation Without False Mapping

## Purpose

This document gives safe language for explaining sensor-derived model features without inventing physical channel names.

## Why Caution Is Needed

The NASA dataset description identifies sensor measurement columns generically. Unless your project adds a verified sensor-name mapping, individual columns `s1` through `s21` should not be explained as specific named physical sensors.

## Safe Explanation Style

It is acceptable to say that a top SHAP feature is a sensor-derived trend, slope, delta, range, or late-window change. It is also acceptable to say the feature may reflect changing engine behavior under operating condition and degradation.

## Unsafe Explanation Style

Avoid saying that a specific sensor proves a specific component failure unless verified by a trusted mapping or failure-mode evidence.

## Recommendation Use

The LLM explanation should say: `The model was influenced by sensor-derived trend features associated with reduced predicted TTE.` It should not say: `Sensor s11 proves HPC failure`, unless that mapping is verified.

## How This Helps Recommendation Reliability

This document improves reliability by reducing hallucinated physical explanations. It keeps final recommendations evidence-grounded.

## Suggested Metadata Tags

- `sensor_interpretation`
- `SHAP`
- `avoid_false_mapping`
- `safe_explanation`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
