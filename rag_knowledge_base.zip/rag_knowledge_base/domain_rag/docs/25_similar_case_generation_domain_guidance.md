# Similar Case Generation Domain Guidance

## Purpose

This document explains how CMAPSS raw data and inference outputs should be transformed into Similar Case RAG documents.

## Do Not Store Raw Rows

Do not store every cycle row as a vector document. Raw rows are too granular and numeric-heavy for semantic retrieval.

## Generate Case Summaries

Create case summaries at useful checkpoints: final observed cycle, critical-focus cycle, warning-stage checkpoint, and selected lifecycle quantiles.

## Recommended Case Fields

A similar case should include dataset subset, unit, sample role, cutoff cycle, predicted TTE, actual TTE if available, uncertainty interval, risk zone, UQ alarm, confidence, top features, action recommendation, and outcome or lesson.

## Subset Matching

For best retrieval, similar cases should include subset metadata. FD004 cases should prefer FD004 or comparable high-complexity cases when available.

## How This Helps Recommendation Reliability

This document improves reliability by preparing the future Similar Case RAG collection. It ensures similar-case evidence is based on summarized trajectories rather than noisy raw rows.

## Suggested Metadata Tags

- `similar_case_rag`
- `case_generation`
- `checkpoint`
- `summary`
- `raw_rows`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
