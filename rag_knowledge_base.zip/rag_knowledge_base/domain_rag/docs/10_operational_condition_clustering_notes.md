# Operational-Condition Clustering Notes

## Purpose

This document explains how operational-condition clustering can support retrieval and recommendation without claiming unsupported labels.

## Purpose of Clustering

In FD002 and FD004, operational settings can be clustered or grouped to identify comparable operating regimes. This is useful because sensor measurements are affected by operating conditions.

## What to Cluster

A practical clustering approach can use the operational-setting columns `op1`, `op2`, and `op3`. The output can be an operational-regime label used for analysis, filtering, or similar-case generation.

## What Clustering Does Not Mean

An operational cluster is not a fault label. It does not prove degradation. It only helps compare engine states under more similar operating conditions.

## RAG and Recommendation Use

If similar cases include operational-regime metadata, the retriever can prefer cases from the same or similar regime. If that metadata is missing, the system should rely on subset, risk zone, TTE bucket, UQ alarm, and confidence.

## How This Helps Recommendation Reliability

This document improves reliability by supporting condition-aware retrieval and avoiding false causal interpretations. It is especially useful for FD002 and FD004.

## Suggested Metadata Tags

- `operational_clustering`
- `op1`
- `op2`
- `op3`
- `similar_case_filtering`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
