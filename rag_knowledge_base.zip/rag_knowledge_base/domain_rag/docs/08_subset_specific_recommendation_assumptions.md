# Subset-Specific Recommendation Assumptions

## Purpose

This document explains how each FD subset should influence recommendation assumptions without inventing unsupported maintenance rules.

## General Rule

Subset information should influence interpretation, retrieval, and confidence handling. It should not automatically force a specific maintenance action unless policy evidence supports that action.

## FD001 Assumption

FD001 is a one-condition, one-fault-mode subset. For FD001, simpler degradation context is expected compared with FD004. If uncertainty is low and risk is not critical, recommendations can be less conservative than comparable high-complexity cases.

## FD002 Assumption

FD002 has six operating conditions and one fault mode. For FD002, operational-condition variation can complicate sensor interpretation. If confidence is low or interval width is high, recommendations should acknowledge the multi-condition context.

## FD003 Assumption

FD003 has one operating condition and two fault modes. Because dual-fault context is present, failure-mode evidence is important for explanations when low TTE or strong degradation signals appear.

## FD004 Assumption

FD004 has six operating conditions and two fault modes. This is the most complex CMAPSS subset. If evidence quality is weak, uncertainty is high, or UQ alarm is active, the recommendation should be conservative unless policy evidence supports a different approach.

## How This Helps Recommendation Reliability

This document improves reliability by making the system subset-aware without overstating certainty. It supports nuanced recommendations that mention complexity and uncertainty instead of giving one generic action for all CMAPSS cases.

## Suggested Metadata Tags

- `subset_assumptions`
- `FD001`
- `FD002`
- `FD003`
- `FD004`
- `recommendation_context`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
