# Domain Evidence Quality Criteria

## Purpose

This document explains how the Evidence Quality Checker should evaluate Domain RAG results.

## Minimum Quality

A good Domain RAG result should be CMAPSS-specific, asset-specific, and relevant to the current inference context. For subset-specific cases, matching FD subset evidence is preferred.

## Strong Evidence

Strong domain evidence mentions the correct dataset, turbofan engine context, RUL/TTE task, subset profile if relevant, operating-condition complexity if relevant, and fault-mode setting if relevant.

## Weak Evidence

Weak evidence is generic predictive-maintenance text that does not mention CMAPSS, turbofan engines, RUL/TTE, FD subsets, operating conditions, or relevant model-output context.

## Evidence Quality Flags

The Evidence Quality Checker can flag missing domain evidence, subset mismatch, low trust level, outdated version, or evidence that is too generic.

## Relationship to Final Recommendation

If domain evidence is weak, the final recommendation can still be generated using policy and model outputs, but it should include an evidence limitation or trigger additional retrieval.

## How This Helps Recommendation Reliability

This document improves reliability by ensuring Domain RAG contributes meaningful context instead of irrelevant text. It helps prevent final recommendations from being source-grounded in the wrong material.

## Suggested Metadata Tags

- `evidence_quality`
- `domain_evidence`
- `coverage`
- `subset_match`
- `quality_checker`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
