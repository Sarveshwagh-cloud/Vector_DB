# Official Sources and Download Links

## Purpose

This document records the authoritative sources used for the CMAPSS Domain RAG collection. It helps preserve traceability and prevents unsupported or random web material from being mixed into the curated domain knowledge base.

## Primary Dataset Source

The primary dataset source is the NASA Open Data Portal page for CMAPSS Jet Engine Simulated Data. This page describes the dataset structure, train/test split, operational settings, sensor columns, and the FD001–FD004 subset summary.

## Direct Data Resource

The direct resource is the CMAPSSData.zip file listed by NASA. This ZIP contains the text files for the four CMAPSS subsets, including training, test, and RUL files.

The raw ZIP should be used for model training, evaluation, and generation of similar-case summaries. It should not be inserted directly into Domain RAG as raw rows.

## Simulator and Damage Propagation Sources

The C-MAPSS User's Guide provides simulator background, including the fact that the software represents a large commercial turbofan engine simulation with a realistic control system and atmospheric/operating condition capability.

The PHM 2008 damage propagation paper provides the run-to-failure simulation context, including sensor response surfaces, flow and efficiency loss, damage propagation, and health-index-based failure criterion.

## Use of Sources

NASA Open Data and NASA technical reports should be treated as high-trust domain sources. Project-authored summaries based on those sources can be treated as curated domain notes. Unsupported blog posts or generic maintenance text should not be added to Domain RAG unless clearly labeled as lower-trust external context.

## How This Helps Recommendation Reliability

This document improves recommendation reliability by making source provenance explicit. It supports evidence auditing, source citation, and conflict resolution. If a generated recommendation cites domain context, the source should be traceable back to NASA dataset or simulator documentation.

## Suggested Metadata Tags

- `official_sources`
- `download`
- `traceability`
- `NASA`
- `source_trust`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
