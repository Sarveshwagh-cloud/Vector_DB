# Operational Settings and Condition Complexity

## Purpose

This document explains how operational settings affect CMAPSS interpretation and why multi-condition subsets need special handling.

## Operational Settings

CMAPSS includes three operational settings that have a substantial effect on engine performance. These settings are part of every row.

## Why They Matter

Sensor values can change because of operating condition changes, not only because of degradation. This means raw sensor comparisons across cycles or units can be misleading without considering operational context.

## Single-Condition vs Multi-Condition

FD001 and FD003 have one operating condition. FD002 and FD004 have six operating conditions. Multi-condition subsets require stronger attention to preprocessing, normalization, uncertainty, and similar-case filtering.

## Recommendation Implication

If a current inference case comes from FD002 or FD004 and has medium/low confidence or a wide uncertainty interval, the final explanation should mention operating-condition complexity as a possible reason for cautious interpretation.

## How This Helps Recommendation Reliability

This document improves reliability by preventing the system from treating operating-condition variation as direct degradation evidence. It also helps similar-case retrieval prefer cases with compatible operating condition context.

## Suggested Metadata Tags

- `operational_settings`
- `multi_condition`
- `FD002`
- `FD004`
- `condition_complexity`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
