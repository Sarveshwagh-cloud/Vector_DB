# FD001 to FD004 Subset Profiles

## Purpose

This document gives a detailed subset-by-subset profile for FD001, FD002, FD003, and FD004. It is one of the most important Domain RAG documents because subset complexity affects retrieval and recommendation interpretation.

## FD001

FD001 contains 100 training trajectories and 100 test trajectories. It has one operating condition and one fault mode: High Pressure Compressor degradation.

FD001 is the simplest subset. Recommendations for FD001 can usually focus on single-condition, single-fault degradation behavior. Similar cases from FD001 are highly relevant for FD001 inference payloads.

## FD002

FD002 contains 260 training trajectories and 259 test trajectories. It has six operating conditions and one fault mode: High Pressure Compressor degradation.

FD002 is more complex than FD001 because operating conditions can strongly affect sensor measurements. Recommendations should consider uncertainty and should prefer similar cases from comparable operating-condition context.

## FD003

FD003 contains 100 training trajectories and 100 test trajectories. It has one operating condition and two fault modes: High Pressure Compressor degradation and fan degradation.

FD003 is more complex than FD001 because degradation can involve two fault modes. Failure-mode evidence should be retrieved when explaining low TTE or SHAP-driven degradation indicators.

## FD004

FD004 contains 248 training trajectories and 249 test trajectories. It has six operating conditions and two fault modes: High Pressure Compressor degradation and fan degradation.

FD004 is the most complex subset because it combines multiple operating conditions with multiple fault modes. For FD004 cases with low TTE, wide uncertainty, or active UQ alarm, conservative and safety-first reasoning should be strongly considered, subject to policy evidence.

## How This Helps Recommendation Reliability

This document improves recommendation reliability by enabling subset-aware retrieval. FD001 and FD004 should not be treated as equivalent. The Query Router should use subset metadata where available and retrieve the matching subset profile.

## Suggested Metadata Tags

- `FD001`
- `FD002`
- `FD003`
- `FD004`
- `subset_profiles`
- `complexity`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
