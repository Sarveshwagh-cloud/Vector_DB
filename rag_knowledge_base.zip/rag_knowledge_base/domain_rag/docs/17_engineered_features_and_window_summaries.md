# Engineered Features and Window Summaries

## Purpose

This document explains the domain meaning of engineered features created from time windows in your inference code.

## Window-Based Prediction

Your inference pipeline creates a fixed-size window ending at the selected cutoff cycle. The model predicts TTE from the recent trajectory context in that window.

## Tabular Window Features

The HGB model receives tabular summaries such as last value, first value, mean, standard deviation, min, max, range, delta, slope, early mean, late mean, and late-minus-early.

## Domain Meaning

These features summarize trajectory behavior. Slope and late-minus-early features can indicate directional change within the window. Range and standard deviation can capture variability. Last values can represent the most recent state.

## Recommendation Use

If SHAP highlights slope or late-minus-early features that decrease predicted TTE, the final explanation can mention that the model detected within-window degradation trend evidence.

## How This Helps Recommendation Reliability

This document improves reliability by connecting model explanation fields to trajectory behavior without claiming unsupported physical causes.

## Suggested Metadata Tags

- `engineered_features`
- `window`
- `slope`
- `delta`
- `SHAP`
- `HGB`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
