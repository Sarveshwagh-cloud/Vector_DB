# Domain RAG Retrieval Test Queries

## Purpose

This document provides test queries for validating the Domain RAG collection after ingestion.

## General Dataset Query

Query: `What is the CMAPSS dataset and how is RUL predicted?`

Expected evidence: dataset overview, train/test behavior, RUL/TTE task definition.

## FD004 Complexity Query

Query: `Explain why FD004 is more complex for recommendation than FD001.`

Expected evidence: FD subset profiles, operating-condition complexity, dual-fault context.

## Operational Settings Query

Query: `Why can operational settings affect sensor interpretation in CMAPSS?`

Expected evidence: operational settings and condition complexity documents.

## SHAP Explanation Query

Query: `How should SHAP top features from sensor slopes be interpreted in CMAPSS?`

Expected evidence: engineered feature interpretation, SHAP domain interpretation, safe sensor mapping.

## Simulation Limitation Query

Query: `Can CMAPSS recommendations be treated as certified aircraft maintenance policy?`

Expected evidence: limitations and safe language documents.

## How This Helps Recommendation Reliability

This document improves reliability by giving you a test suite for checking whether the vector database retrieves the correct Domain RAG evidence before connecting it to the full recommendation pipeline.

## Suggested Metadata Tags

- `retrieval_tests`
- `domain_rag`
- `validation`
- `test_queries`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
