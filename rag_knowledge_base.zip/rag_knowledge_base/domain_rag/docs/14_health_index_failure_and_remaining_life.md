# Health Index, Failure, and Remaining Life

## Purpose

This document explains how failure and remaining life should be understood in the PHM08/CMAPSS context.

## Health Index Context

The PHM08 paper describes a health-index-based failure criterion. In that context, remaining useful life is the number of cycles before the simulated failure condition is reached.

## What a Low TTE Means

A low predicted TTE means the current trajectory is estimated to be close to failure in terms of remaining operational cycles. It does not mean the engine has already failed.

## What a UQ Lower Bound Means

If the lower uncertainty bound is very low, the model's conservative estimate suggests the engine may be closer to failure than the point prediction alone indicates.

## Recommendation Implication

The recommendation should distinguish between point-risk and uncertainty-aware risk. A UQ-aware critical case should not be treated like a safe high-confidence case.

## How This Helps Recommendation Reliability

This document helps make recommendations more reliable by connecting prediction values to the simulated failure criterion while avoiding overclaiming real-world failure timing.

## Suggested Metadata Tags

- `health_index`
- `failure_criterion`
- `remaining_life`
- `UQ_lower_bound`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
