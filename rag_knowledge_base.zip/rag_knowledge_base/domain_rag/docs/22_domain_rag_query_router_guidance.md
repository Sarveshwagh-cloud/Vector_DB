# Domain RAG Query Router Guidance

## Purpose

This document explains how the Query Router should create queries for the Domain RAG collection.

## Always Query Domain RAG

Domain RAG should be queried for every recommendation because it provides dataset and asset context.

## Query Inputs

Useful query inputs include subset, predicted TTE, risk zone, UQ alarm status, confidence, interval width, SHAP top features, model disagreement, and sample role.

## Example Queries

For a critical FD004 case:
`Explain CMAPSS FD004 turbofan RUL prediction with low predicted TTE, active UQ alarm, six operating conditions, and two fault modes.`

For a generic deployment case:
`Explain CMAPSS turbofan engine RUL prediction, training versus test behavior, and how predicted TTE should be interpreted.`

## Retrieval Strategy

Use dense-heavy hybrid retrieval. Domain queries are often semantic, but sparse matching helps exact terms such as FD001, FD002, FD003, FD004, RUL, TTE, HPC, fan degradation, and operational settings.

## How This Helps Recommendation Reliability

This document improves reliability by standardizing how current inference outputs are converted into domain retrieval queries. It also makes Domain RAG behavior predictable and testable.

## Suggested Metadata Tags

- `query_router`
- `domain_query`
- `hybrid_retrieval`
- `FD004`
- `UQ_alarm`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
