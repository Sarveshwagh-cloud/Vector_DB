# Domain RAG Metadata Guidelines Detailed

## Purpose

This document provides detailed metadata guidance for Domain RAG chunks. It replaces short placeholder metadata notes with full operational guidance.

## Why Metadata Matters

Metadata is structured information stored with every chunk in Qdrant. It tells the system what the chunk applies to, where it came from, how trustworthy it is, and how it should be used.

For Domain RAG, metadata supports subset-aware retrieval, evidence quality checking, source citation, conflict resolution, and final recommendation traceability.

## Required Fields

Each domain chunk should include `collection_name`, `rag_type`, `source_id`, `chunk_id`, `source_file`, `dataset`, `asset_type`, `topic`, `trust_level`, `source_priority`, and `version`.

For this collection, `collection_name` should be `domain_rag`, `rag_type` should be `domain`, `dataset` should be `CMAPSS`, and `asset_type` should be `turbofan_engine`.

## FD-Specific Fields

FD-specific chunks should also include `subset`, `operating_condition_count`, `fault_mode_count`, and `fault_modes`.

Example: FD004 should include subset `FD004`, operating condition count `6`, fault mode count `2`, and fault modes `HPC degradation` and `Fan degradation`.

## Filtering and Boosting

If the inference payload identifies a subset, the retriever can filter or boost matching subset evidence. For example, an FD004 inference case should prefer FD004 domain evidence and then fall back to general CMAPSS evidence.

## Example Metadata

A good metadata payload for an FD004 domain chunk is:

```json
{
  "collection_name": "domain_rag",
  "rag_type": "domain",
  "source_id": "DOMAIN_FD004_PROFILE",
  "chunk_id": "DOMAIN_FD004_PROFILE_CHUNK_001",
  "source_file": "07_fd001_fd004_subset_profiles.md",
  "dataset": "CMAPSS",
  "asset_type": "turbofan_engine",
  "subset": "FD004",
  "operating_condition_count": 6,
  "fault_mode_count": 2,
  "fault_modes": ["HPC degradation", "Fan degradation"],
  "topic": "subset_profile",
  "trust_level": "high",
  "source_priority": 2,
  "version": "v1.0"
}
```

## Reliability Impact

Metadata prevents irrelevant retrieval, supports subset-aware reasoning, enables source citations, and helps the Evidence Quality Checker determine whether the retrieved domain evidence is sufficient.

## How This Helps Recommendation Reliability

This document improves recommendation reliability by making Domain RAG retrieval controllable and auditable. Without metadata, the retriever may return generic or mismatched evidence, weakening the final recommendation.

## Suggested Metadata Tags

- `metadata`
- `Qdrant`
- `payload`
- `filtering`
- `source_id`
- `trust_level`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
