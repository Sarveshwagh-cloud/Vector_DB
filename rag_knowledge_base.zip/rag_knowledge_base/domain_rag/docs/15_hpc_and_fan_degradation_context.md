# HPC and Fan Degradation Context

## Purpose

This document explains the official fault-mode context used by the CMAPSS subsets.

## HPC Degradation

FD001 and FD002 are described as having one fault mode: High Pressure Compressor degradation. FD003 and FD004 include High Pressure Compressor degradation as part of the two-fault-mode setting.

## Fan Degradation

FD003 and FD004 are described as having two fault modes: High Pressure Compressor degradation and fan degradation.

## Domain Boundary

This document does not claim that a specific sensor channel proves HPC or fan degradation. It only states the subset-level fault-mode context described for CMAPSS.

## Recommendation Use

If the current case is FD003 or FD004, the Query Router should retrieve failure-mode evidence for both HPC and fan degradation context. If the current case is FD001 or FD002, HPC degradation context is the relevant official fault mode.

## How This Helps Recommendation Reliability

This document improves reliability by aligning failure-mode explanations with official subset descriptions instead of unsupported generic machine-failure modes.

## Suggested Metadata Tags

- `HPC_degradation`
- `fan_degradation`
- `fault_modes`
- `FD001`
- `FD002`
- `FD003`
- `FD004`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
