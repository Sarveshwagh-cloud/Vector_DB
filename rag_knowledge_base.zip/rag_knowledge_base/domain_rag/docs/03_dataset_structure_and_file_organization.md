# Dataset Structure and File Organization

## Purpose

This document explains how CMAPSS files are organized and how this organization should influence RAG ingestion and recommendation-system design.

## Standard Files

The CMAPSS package is typically organized into train, test, and RUL files for FD001, FD002, FD003, and FD004. Training files contain complete run-to-failure trajectories. Test files contain truncated trajectories. RUL files provide the ground-truth remaining useful life values for test units.

## Why Raw Rows Should Not Go Into Domain RAG

The raw data contains many numeric cycle-level rows. Those rows are important for model training, evaluation, and case generation, but they are not useful as domain explanation chunks.

Domain RAG should contain curated explanatory documents. Similar Case RAG should contain generated case summaries. Raw files should stay in data storage or processing pipelines.

## Correct Use in the Recommendation Pipeline

Use raw CMAPSS files to train models, evaluate predictions, and generate structured case summaries. Use Domain RAG to explain what the dataset, subset, and trajectory mean. Use Similar Case RAG to retrieve previous engine/checkpoint cases based on risk zone, predicted TTE, uncertainty, and outcome.

## How This Helps Recommendation Reliability

This document prevents a common RAG design error: putting raw numeric rows into the vector database as if they were explanatory knowledge. That would pollute retrieval and make the final recommendation less reliable.

## Suggested Metadata Tags

- `file_structure`
- `train_files`
- `test_files`
- `RUL_files`
- `raw_data_boundary`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
