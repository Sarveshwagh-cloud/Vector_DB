# Column Schema and Record Meaning

## Purpose

This document explains the CMAPSS row schema and how the columns should be interpreted in a recommendation context.

## Official Row Structure

Each CMAPSS row is a snapshot from a single operational cycle. The official schema is 26 columns: unit number, time in cycles, three operational settings, and sensor measurements.

In many code pipelines, these columns are renamed to `unit`, `cycle`, `op1`, `op2`, `op3`, and `s1` through `s21`.

## Meaning of Unit and Cycle

The unit number identifies the engine trajectory. The cycle number is the operational time index. A prediction at a cycle cutoff should be interpreted as a forecast from that observed point forward.

## Meaning of Operational Settings

The three operational settings substantially affect engine performance and sensor values. Therefore, differences in sensor readings may be due to operating condition, not only degradation.

## Meaning of Sensor Measurements

The public dataset page names the channels generically as sensor measurements. Unless your project has a verified sensor-name mapping, explanations should avoid claiming exact physical meanings for individual channels such as `s7` or `s11`.

It is safe to say that model features derived from these sensors may capture trends, variation, degradation signatures, or operating-condition effects, but the final explanation should avoid unsupported physical causality.

## How This Helps Recommendation Reliability

This document improves reliability by preventing overinterpretation of raw sensor columns. It supports careful explanations like: “The model relied on sensor-derived trend features,” rather than unsupported claims like: “sensor 11 proves compressor failure,” unless verified by trusted documentation.

## Suggested Metadata Tags

- `column_schema`
- `unit`
- `cycle`
- `operational_settings`
- `sensor_measurements`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
