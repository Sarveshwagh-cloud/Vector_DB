# RUL and TTE Prediction Task

## Purpose

This document explains how Remaining Useful Life and Time-to-Event should be interpreted for CMAPSS recommendations.

## RUL and TTE

Remaining Useful Life and Time-to-Event both refer to the estimated number of cycles remaining before the simulated failure point. In your project, `predicted_tte` is the operational value used by the recommendation pipeline.

## Point Prediction Is Not Enough

A single point prediction should not be the only basis for action. The recommendation system should also consider lower and upper uncertainty bounds, interval width, confidence, UQ alarms, model disagreement, and retrieved policy evidence.

## Lower Bound Interpretation

The lower bound of an uncertainty interval is important because it represents a more conservative possible remaining life. If the 95% lower bound is below an alarm threshold, the recommendation should become more conservative even if the point prediction is higher.

## Decision-Support Meaning

The prediction estimates remaining cycles; the recommendation system converts that estimate into action options such as monitoring, inspection, maintenance planning, expert review, or immediate maintenance depending on policy and scoring objectives.

## How This Helps Recommendation Reliability

This document improves recommendation reliability by separating prediction from decision. It prevents the system from saying “the model predicts 45 cycles, so no action is needed” without considering uncertainty, confidence, and policy constraints.

## Suggested Metadata Tags

- `RUL`
- `TTE`
- `prediction_task`
- `uncertainty`
- `decision_support`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
