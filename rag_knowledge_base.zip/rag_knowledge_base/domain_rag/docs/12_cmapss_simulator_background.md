# C-MAPSS Simulator Background

## Purpose

This document gives the simulator background needed for domain-level interpretation.

## What C-MAPSS Is

C-MAPSS is a NASA-developed Commercial Modular Aero-Propulsion System Simulation. It is described as a transient simulation of a large commercial turbofan engine with a realistic control system.

## Operating Capability

The simulator supports engine operation across a range of flight/ambient conditions and thrust settings. It includes an atmospheric model and a power-management system, according to the NASA C-MAPSS User's Guide record.

## Why This Matters

CMAPSS sensor data comes from a structured turbofan simulation environment, not arbitrary generated noise. The domain context therefore includes engine behavior, control response, operating condition, and degradation progression.

## Recommendation Implication

The recommendation system should avoid simplistic one-sensor reasoning. It should rely on model prediction, uncertainty, feature trends, and retrieved domain/failure-mode evidence.

## How This Helps Recommendation Reliability

This document improves reliability by grounding explanations in the simulator background. It helps the LLM explain why operating conditions and control behavior can affect sensor patterns.

## Suggested Metadata Tags

- `C-MAPSS`
- `simulator`
- `turbofan`
- `control_system`
- `operating_envelope`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
