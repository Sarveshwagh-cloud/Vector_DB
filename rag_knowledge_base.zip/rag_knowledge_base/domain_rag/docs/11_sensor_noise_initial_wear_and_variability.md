# Sensor Noise, Initial Wear, and Variability

## Purpose

This document explains three important sources of variation in CMAPSS: sensor noise, initial wear, and manufacturing variation.

## Sensor Noise

CMAPSS data is contaminated with sensor noise. This means isolated sensor fluctuations should not automatically be interpreted as degradation.

## Initial Wear

Each engine starts with different unknown initial wear. This is considered normal variation, not a fault condition.

## Manufacturing Variation

Manufacturing variation can make healthy engines look different from one another early in their trajectories.

## Recommendation Implication

The recommendation system should use model prediction, uncertainty, trajectory summaries, SHAP, attention, and evidence—not isolated raw sensor movement—as the basis for action.

## How This Helps Recommendation Reliability

This document improves reliability by preventing false alarms based only on raw sensor variation. It supports cautious language and evidence-based recommendations.

## Suggested Metadata Tags

- `sensor_noise`
- `initial_wear`
- `manufacturing_variation`
- `false_alarm_prevention`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
