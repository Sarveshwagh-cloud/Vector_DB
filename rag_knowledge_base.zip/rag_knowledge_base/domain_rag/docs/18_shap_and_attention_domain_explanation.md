# SHAP and CNN Attention Domain Explanation

## Purpose

This document explains how SHAP and CNN attention should be used in Domain RAG explanations.

## SHAP

SHAP explains how HGB tabular features influence the model prediction. A negative SHAP value decreases predicted TTE; a positive SHAP value increases predicted TTE.

## CNN Attention

CNN attention summaries show which time steps in the sequence model window received higher attention. Recent high attention may suggest the model focused on late-window behavior; distributed attention may suggest broader trajectory context.

## Causality Limitation

SHAP and attention explain model behavior, not guaranteed physical causality. They should support explanation but should not override uncertainty, policy, or evidence-quality checks.

## Recommendation Use

Use SHAP and attention to make the recommendation explanation more transparent. Do not use them alone as hard maintenance triggers.

## How This Helps Recommendation Reliability

This document improves reliability by making model explanations useful but bounded. It helps the LLM explain why the model predicted low or high TTE while avoiding false causal claims.

## Suggested Metadata Tags

- `SHAP`
- `CNN_attention`
- `model_explanation`
- `causality_limit`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
