# Recommendation Modes Domain Context

## Purpose

This document explains how different recommendation modes relate to CMAPSS domain context without defining hard policies.

## Balanced

Balanced mode should consider predicted TTE, uncertainty, risk zone, policy evidence, downtime impact, and cost proxy together.

## Safety-First

Safety-first mode should prioritize avoiding missed critical failures, especially when predicted TTE is low or UQ alarm is active.

## Cost-Optimized

Cost-optimized mode may prefer planned action over immediate maintenance, but it must not violate policy or ignore active UQ alarms.

## Downtime-Minimized

Downtime-minimized mode should reduce disruption while still respecting safety and uncertainty constraints.

## Conservative

Conservative mode is appropriate when uncertainty is high, confidence is low, evidence is weak, or subset complexity is high.

## How This Helps Recommendation Reliability

This document improves reliability by giving the scoring layer domain context for modes while leaving mandatory action rules to Policy RAG.

## Suggested Metadata Tags

- `recommendation_modes`
- `balanced`
- `safety_first`
- `cost_optimized`
- `conservative`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
