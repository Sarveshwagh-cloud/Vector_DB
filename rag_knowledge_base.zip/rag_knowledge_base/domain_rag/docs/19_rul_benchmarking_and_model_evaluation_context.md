# RUL Benchmarking and Model Evaluation Context

## Purpose

This document explains why CMAPSS is used for RUL benchmarking and how benchmark metrics should affect recommendations.

## Benchmark Role

CMAPSS is widely used as a benchmark dataset for RUL prediction. It is suitable for testing regression, sequence, deep learning, and ensemble prognostics models.

## Metrics Are Not Actions

Metrics such as RMSE, MAE, R2, coverage, CFMR, UCE, UWE, and NASA-style scoring evaluate model behavior. They do not directly define the maintenance action.

## Recommendation Use

The recommendation system should use metrics to understand model reliability and risk of wrong decisions. Action selection should still pass through policy constraints and multi-objective scoring.

## Asymmetric Error Meaning

In RUL settings, over-predicting remaining life may be operationally risky because it can delay intervention. Under-predicting may be conservative but can increase unnecessary downtime or cost.

## How This Helps Recommendation Reliability

This document improves reliability by connecting model metrics to decision risk without confusing model performance with policy authority.

## Suggested Metadata Tags

- `benchmarking`
- `RMSE`
- `MAE`
- `NASA_score`
- `model_evaluation`
- `decision_risk`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
