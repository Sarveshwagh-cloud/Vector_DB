# Train, Test, and Deployment Interpretation

## Purpose

This document explains the difference between train, test, and deployment-style inference in CMAPSS.

## Training Trajectories

Training trajectories run until failure. They contain the full progression from normal operation to failure. They are appropriate for learning degradation and for generating historical case summaries.

## Test Trajectories

Test trajectories are truncated before failure. Their final rows represent engines that are still operating but have unknown remaining cycles from the model's perspective. The true RUL values are provided separately for evaluation.

## Deployment-Like Inference

Your inference pipeline has `deployment_test_like`, `checkpoint_history`, and `critical_focus` roles. These are model-evaluation and recommendation-testing views of an engine trajectory.

A deployment-like row should be treated as a current case: the engine has observed history up to a cutoff cycle, and the system must recommend action based on prediction, uncertainty, and evidence.

## Recommendation Consequence

The final recommendation should not assume that a test/deployment engine has already failed. It should recommend proactive action before predicted failure.

## How This Helps Recommendation Reliability

This document improves reliability by keeping the system from confusing train run-to-failure data with current deployment state. It helps explain why recommendations are made before failure, not after failure.

## Suggested Metadata Tags

- `train`
- `test`
- `deployment`
- `checkpoint_history`
- `critical_focus`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
