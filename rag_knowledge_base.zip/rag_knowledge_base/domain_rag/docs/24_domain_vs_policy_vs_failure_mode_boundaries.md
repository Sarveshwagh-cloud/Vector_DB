# Domain vs Policy vs Failure-Mode Boundaries

## Purpose

This document defines the boundary between Domain RAG and other RAG collections.

## Domain RAG

Domain RAG explains CMAPSS, turbofan simulation context, subset complexity, operating conditions, sensor interpretation assumptions, and trajectory meaning.

## Policy RAG

Policy RAG defines action constraints, safety rules, escalation rules, threshold rules, and mandatory or blocked actions.

## Failure Mode RAG

Failure Mode RAG explains possible degradation modes such as HPC degradation and fan degradation and how evidence may support inspection focus.

## Boundary Rule

Domain RAG should not declare mandatory actions. For example, Domain RAG can say FD004 is more complex and may require cautious interpretation. Policy RAG should say whether inspection is mandatory under active UQ alarm.

## Conflict Rule

If domain context and policy evidence appear to conflict, policy should govern action. Domain should explain context, not override hard constraints.

## How This Helps Recommendation Reliability

This document improves reliability by preventing authority confusion. It keeps the recommendation engine from treating explanatory domain text as hard safety policy.

## Suggested Metadata Tags

- `domain_rag`
- `policy_rag`
- `failure_mode_rag`
- `authority`
- `boundaries`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
