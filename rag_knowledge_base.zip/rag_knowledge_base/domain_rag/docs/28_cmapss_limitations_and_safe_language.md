# CMAPSS Limitations and Safe Language

## Purpose

This document defines safe wording and limitations for final recommendation explanations.

## Simulation Limitation

CMAPSS is simulated data. It is suitable for predictive-maintenance research and recommendation-system prototyping, but it is not certified aircraft maintenance evidence.

## No Real Maintenance Logs

CMAPSS does not provide real maintenance actions, spare-part data, labor availability, or actual inspection reports. Those must come from project-defined policy, synthetic assumptions, or future feedback logs.

## Safe Language

Use language such as `model-driven recommendation`, `simulated turbofan benchmark context`, `decision-support output`, and `uncertainty-aware action option`.

## Avoid Overclaiming

Do not say the recommendation is certified, regulatory, or guaranteed to prevent failure. Do not claim exact physical root cause unless supported by verified evidence.

## How This Helps Recommendation Reliability

This document improves reliability by forcing the final output to be honest about scope and limitations.

## Suggested Metadata Tags

- `limitations`
- `safe_language`
- `simulation`
- `decision_support`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
