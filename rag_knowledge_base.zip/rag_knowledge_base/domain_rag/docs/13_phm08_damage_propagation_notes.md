# PHM08 Damage Propagation Notes

## Purpose

This document summarizes the key domain ideas from the PHM 2008 damage propagation paper without reproducing copyrighted paper text.

## Damage Propagation Modeling

The PHM 2008 paper describes how damage propagation can be modeled within aircraft gas-turbine engine modules. Sensor response surfaces are generated from a thermo-dynamical engine simulation model as module flow and efficiency vary.

## Flow and Efficiency Loss

The paper describes exponential flow and efficiency loss rates that represent an unspecified fault with worsening effect. The starting point of deterioration is randomly chosen.

## Failure Criterion

Damage propagation continues until a failure criterion is reached. The paper describes a health index derived from operational margins, with failure occurring when the health index reaches zero.

## Recommendation Implication

Low predicted TTE should be interpreted as a simulated near-failure state. If uncertainty lower bounds are also low, the recommendation should favor conservative or safety-first options, subject to policy rules.

## How This Helps Recommendation Reliability

This document improves reliability by explaining why the time series has progressive degradation structure. It supports recommendations that refer to degradation progression rather than random deterioration.

## Suggested Metadata Tags

- `PHM08`
- `damage_propagation`
- `flow_loss`
- `efficiency_loss`
- `health_index`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
