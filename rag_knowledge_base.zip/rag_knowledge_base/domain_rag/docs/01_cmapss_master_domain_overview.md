# CMAPSS Master Domain Overview

## Purpose

This document gives the main domain context for the NASA CMAPSS Jet Engine Simulated Data dataset. It should be one of the primary retrieval targets whenever the recommendation system needs to explain what the current TTE/RUL prediction means in the CMAPSS setting.

## What CMAPSS Represents

CMAPSS Jet Engine Simulated Data is a simulated turbofan engine degradation dataset used for prognostics and Remaining Useful Life prediction. The dataset consists of multiple multivariate time series. Each time series corresponds to one engine unit from a fleet of engines of the same type.

The dataset is organized so that each row is a measurement snapshot from one operational cycle. The row contains an engine unit number, cycle number, operational settings, and sensor measurements. The data is not a single static tabular dataset; it is a collection of engine trajectories through time.

## How Degradation Appears

The engines start in normal operation. They have different levels of initial wear and manufacturing variation, but this variation is treated as normal and not as a fault. At some point in the trajectory, a fault develops and grows until failure in the training set.

This means the recommendation system should reason about trajectory stage, predicted remaining cycles, uncertainty, and model evidence rather than treating every sensor difference as a fault.

## Training and Test Meaning

Training trajectories run until failure, which makes them useful for learning degradation progression. Test trajectories end before failure, and the target task is to estimate how many cycles remain after the last observed cycle.

A deployment-style inference request is conceptually similar to a test trajectory: the model sees data up to a cutoff cycle and predicts remaining useful life from that point.

## What Domain RAG Should Provide

Domain RAG should provide context, not hard maintenance policy. It explains the dataset, subset complexity, operating conditions, fault-mode setting, trajectory behavior, simulation limitations, and interpretation assumptions.

Hard action rules such as mandatory inspection, escalation, or blocked normal operation should be stored in `policy_rag`, not in `domain_rag`.

## How This Helps Recommendation Reliability

This document improves reliability by grounding the recommendation in the correct dataset context. It helps prevent the system from applying generic machine-maintenance assumptions to a CMAPSS turbofan simulation case. It also reminds the recommendation system that the prediction is trajectory-based and uncertainty-aware, not a direct observation of actual aircraft maintenance status.

## Suggested Metadata Tags

- `CMAPSS`
- `dataset_overview`
- `turbofan_engine`
- `RUL`
- `TTE`
- `domain_context`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
