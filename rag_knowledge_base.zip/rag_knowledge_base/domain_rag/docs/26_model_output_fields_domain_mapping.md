# Model Output Fields to Domain Meaning Mapping

## Purpose

This document maps your inference output fields to domain interpretation.

## Predicted TTE

`predicted_tte` estimates remaining cycles before the simulated failure point.

## Uncertainty Bounds

`lower_bound_90`, `upper_bound_90`, `lower_bound_95`, and `upper_bound_95` describe uncertainty around the prediction. The lower bound is important for conservative risk reasoning.

## Confidence

In your inference pipeline, confidence is derived from uncertainty interval width. Wider intervals imply lower confidence.

## Risk Zone

`risk_zone` maps point predicted TTE to project-defined categories such as Critical, Warning, Caution, and Safe.

## UQ Alarm

`uq_alarm_95` indicates that the 95% lower bound crossed the project-defined alarm threshold. It should trigger conservative interpretation.

## SHAP and Attention

SHAP and CNN attention explain model behavior. They support explanation but do not independently prove physical root cause.

## How This Helps Recommendation Reliability

This document improves reliability by ensuring the LLM and recommendation engine interpret inference fields consistently and avoid unsupported meanings.

## Suggested Metadata Tags

- `inference_output`
- `predicted_tte`
- `confidence`
- `UQ_alarm`
- `SHAP`
- `attention`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
