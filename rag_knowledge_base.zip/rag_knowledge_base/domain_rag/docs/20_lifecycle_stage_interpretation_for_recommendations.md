# Lifecycle Stage Interpretation for Recommendations

## Purpose

This document explains how predicted TTE can be mapped to lifecycle stages in a recommendation context.

## Lifecycle Concept

A practical recommendation system can group predicted TTE into lifecycle/risk stages such as Safe, Caution, Warning, and Critical.

## Project Thresholds

Your inference code uses project-defined thresholds: Critical below 30 cycles, Warning below 60 cycles, Caution below 90 cycles, and Safe otherwise. These are project thresholds, not official NASA maintenance thresholds.

## Uncertainty-Aware Stage

The point prediction risk stage should be combined with UQ-aware risk. If the lower bound of the 95% interval crosses the alarm threshold, the system should consider a more conservative interpretation.

## Recommendation Use

Lifecycle stage helps generate candidate actions, but final action selection should also consider policy evidence, confidence, similar cases, and failure-mode evidence.

## How This Helps Recommendation Reliability

This document improves reliability by clearly separating project-defined risk thresholds from NASA dataset facts. It helps prevent false claims that NASA prescribed these exact maintenance thresholds.

## Suggested Metadata Tags

- `risk_zone`
- `lifecycle_stage`
- `critical`
- `warning`
- `caution`
- `safe`
- `project_thresholds`

## Source Basis

This document is based on the NASA CMAPSS Jet Engine Simulated Data dataset description, the NASA CMAPSSData.zip resource page, the PHM 2008 damage propagation paper/DASHlink summary, and the NASA C-MAPSS User's Guide record. It avoids unsupported physical mapping of individual `s1`–`s21` sensor channels unless that mapping is explicitly available in trusted project documentation.

## Source URLs

- nasa_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_dataset_resource_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_dashlink_page: https://c3.ndc.nasa.gov/dashlink/resources/740/
- cmapss_users_guide_ntrs: https://ntrs.nasa.gov/citations/20070034949
- nasa_pcoe_repository: https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/

---
Collection: `domain_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
