# Domain RAG v3: Deep CMAPSS Domain Collection

This package contains detailed, source-grounded Domain RAG documents for the NASA CMAPSS Jet Engine Simulated Data recommendation system.

## What is inside

- 30 detailed markdown documents
- metadata.json
- domain_rag_v3_summary.json

## Collection mapping

`rag_knowledge_base/domain_rag/docs/` maps to Qdrant collection `domain_rag`.

## Design rules

1. Use source-grounded CMAPSS facts.
2. Avoid unsupported physical mapping of `s1` to `s21` sensors.
3. Domain RAG explains context.
4. Policy RAG defines hard actions.
5. Similar Case RAG stores summarized cases, not raw rows.

## Main sources

- NASA CMAPSS dataset page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- NASA CMAPSSData.zip resource: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data/resource/5224bcd1-ad61-490b-93b9-2817288accb8
- Direct ZIP: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- PHM08 damage propagation paper: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- C-MAPSS User's Guide: https://ntrs.nasa.gov/citations/20070034949
