# Full Test UQ Metrics Reference

## Purpose

This document stores and interprets the supplied full-test Weighted Ensemble UQ metrics, which serve as the realistic, broad performance baseline. It matters because the full-test numbers, not the easier selected subset, are the honest expectation for deployment behavior. Use it as the reference whenever a baseline is needed for context or audit. It applies system-wide.

## Core Performance

The full-test UQ metrics are RMSE 11.9784, MAE 8.5395, R2 0.9107, P90AE 20.1220, P95AE 25.0432, MAX_AE 41.8587, BIAS 0.2543, and ABS_BIAS 0.2543. Together these say the model fits well globally (high R2, single-digit-to-low-double-digit average error) but has a meaningful error tail (MAX_AE near 42) and a nearly neutral, slightly optimistic bias. Use these as the broad expectation for accuracy and error spread. The tail and the small positive bias are the parts most relevant to safety.

## Uncertainty

Coverage_90 = 0.8900 and Coverage_95 = 0.9400, with Mean_Width_90 = 35.9118, Mean_Width_95 = 42.8475, UCE_90 = 0.0300, and UCE_95 = 0.0200, indicating near-target coverage with moderately wide intervals. The small UCE values confirm the intervals are well-calibrated on the full test set. Use these as evidence that the UQ intervals can be trusted in aggregate. Near-target coverage with low UCE is the calibration profile the system is designed for.

## Risk and Alarms

The critical alarm rate at 30 = 0.2300 and at 33 = 0.2700, while UQ alarm 90 rate = 0.3300 and UQ alarm 95 rate = 0.3500, so UQ alarms activate more often than point critical alarms, indicating conservative, uncertainty-aware risk detection. The higher UQ-alarm rates reflect the lower bound catching cases the point value would not. Use this gap to explain why the system flags more cases under UQ logic. It is the population-level footprint of the alarm layer's conservatism.

## Custom Metrics

The full-test custom metrics are RWE 13.0022, ARAE 17.3333, DAS 0.8400, CFMR 0.1600, Decision CFMR@33 0.0000, UQ Decision CFMR values 0.0000, TMC 62500, EWG -0.2543, RADS 0.6400, UWE_90 0.4728, and UWE_95 0.3995. The standout pairing is point CFMR 0.1600 against Decision CFMR 0.0000, which shows the alarm layer recovering criticals the point model missed, while DAS 0.84 and RADS 0.64 give the realistic risk-classification quality. Use this block as the honest safety-and-decision baseline. The point-vs-decision CFMR contrast is the key safety evidence to cite.

## How This Improves Recommendation Reliability

This gives the recommendation system a concrete performance baseline for the full-test run and helps explain global model reliability. Having the broad numbers on record is what keeps later, more favorable subset results in perspective. The result is recommendations anchored to realistic, not cherry-picked, performance.

## Suggested Metadata Tags

- `full_test_metrics`
- `UQ_metrics`
- `weighted_ensemble`
- `baseline_reference`

## Source Basis

This document is grounded in authentic, citable sources together with this project's own outputs. The standard concepts are referenced to canonical sources: regression-metric definitions follow the scikit-learn model-evaluation user guide; conformal-prediction concepts follow Angelopoulos & Bates, *A Gentle Introduction to Conformal Prediction* (arXiv:2107.07511); SHAP follows Lundberg & Lee (2017, arXiv:1705.07874); the asymmetric NASA prognostics score follows Saxena et al. (2008), *Metrics for Evaluating Performance of Prognostics Techniques*; and the CMAPSS RUL/TTE task follows the NASA Open Data Portal entry and the PHM 2008 damage-propagation paper (Saxena, Goebel, Simon, Eklund; DOI 10.1109/PHM.2008.4711414). All numeric values and the custom metrics (map_risk, RWE, ARAE, DAS, CFMR, Decision/UQ-Decision CFMR, TMC, CRR, UWE, RADS, RTC) are this project's own: they come from the user-provided inference/ensemble/UQ outputs and the Custom_Metrics.py code, and the 25-sample values are corroborated by the provided inference run (20260604_233130). Project-defined metrics and thresholds are labelled as project-defined and are not presented as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_ieee_doi: https://doi.org/10.1109/PHM.2008.4711414
- nasa_prognostics_metrics_paper: https://data.nasa.gov/dataset/metrics-for-evaluating-performance-of-prognostics-techniques
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_intro_arxiv: https://arxiv.org/abs/2107.07511
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_paper_arxiv: https://arxiv.org/abs/1705.07874
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- sklearn_regression_metrics: https://scikit-learn.org/stable/modules/model_evaluation.html
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
