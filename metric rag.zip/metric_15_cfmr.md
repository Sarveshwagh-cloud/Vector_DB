# CFMR: Critical Failure Miss Rate

## Purpose

This document explains the project-defined custom metric CFMR from the user-provided Custom_Metrics.py code, which is the single most safety-critical metric in the set. It matters because a missed critical case is far more dangerous than a conservative false alarm. Use it whenever CFMR appears. It applies system-wide; CFMR is this project's own metric.

## Definition and Formula Logic

CFMR measures how often actual critical cases (y_true < 30) are missed by the point critical classification (y_pred < 30), and if there are no actual high-risk cases it returns 0. It is, in effect, the miss rate on the cases where a miss matters most. Use CFMR to quantify the model's exposure to the worst kind of error, an undetected near-failure. The "0 if no critical cases" rule means a 0 can mean either no misses or no critical cases present, which must be read in context.

## Reported Interpretation

The full test CFMR was 0.1600, meaning 16% of actual critical cases were missed by the point critical classification, while in the 25-sample final inference run CFMR was 0.0000 (corroborated by the provided run 20260604_233130). The full-test 0.16 is the honest safety concern; the 25-sample 0.0 reflects either no missed criticals or few/no critical cases in that subset. Use the full-test value as the realistic safety expectation and pair the 25-sample 0.0 with the decision-CFMR result for proper context. The contrast is exactly why point CFMR alone is not the whole safety story.

## Recommendation Use

CFMR is crucial for safety because missed critical cases can be far more dangerous than conservative false alarms, so a non-zero point CFMR is a strong argument for the uncertainty-aware alarm layer. It directly measures the failure mode the whole system is built to avoid. Use CFMR to justify leaning on UQ alarms and conservative handling near the critical threshold. It is the metric that most clearly ties evaluation to safety.

## Boundary

This is a project-defined metric and should be explained as part of this project's evaluation framework, not as an official NASA maintenance rule. The 30-cycle critical cutoff is a project choice. Use the project-defined label when citing it. The label keeps its custom basis explicit.

## How This Improves Recommendation Reliability

This improves recommendation reliability by converting the most safety-critical metric into evidence-backed decision context. Measuring missed criticals is what keeps the system honest about its core safety risk. The result is recommendations that take undetected near-failures seriously.

## Suggested Metadata Tags

- `CFMR`
- `critical_failure_miss_rate`
- `missed_critical`

## Source Basis

This document is grounded in authentic, citable sources together with this project's own outputs. The standard concepts are referenced to canonical sources: regression-metric definitions follow the scikit-learn model-evaluation user guide; conformal-prediction concepts follow Angelopoulos & Bates, *A Gentle Introduction to Conformal Prediction* (arXiv:2107.07511); SHAP follows Lundberg & Lee (2017, arXiv:1705.07874); the asymmetric NASA prognostics score follows Saxena et al. (2008), *Metrics for Evaluating Performance of Prognostics Techniques*; and the CMAPSS RUL/TTE task follows the NASA Open Data Portal entry and the PHM 2008 damage-propagation paper (Saxena, Goebel, Simon, Eklund; DOI 10.1109/PHM.2008.4711414). All numeric values and the custom metrics (map_risk, RWE, ARAE, DAS, CFMR, Decision/UQ-Decision CFMR, TMC, CRR, UWE, RADS, RTC) are this project's own: they come from the user-provided inference/ensemble/UQ outputs and the Custom_Metrics.py code, and the 25-sample values are corroborated by the provided inference run (20260604_233130). Project-defined metrics and thresholds are labelled as project-defined and are not presented as official NASA maintenance policy.

## Source URLs

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- phm08_damage_propagation_pdf: https://c3.ndc.nasa.gov/dashlink/static/media/publication/2008_IEEEPHM_CMAPPSDamagePropagation.pdf
- phm08_ieee_doi: https://doi.org/10.1109/PHM.2008.4711414
- nasa_prognostics_metrics_paper: https://data.nasa.gov/dataset/metrics-for-evaluating-performance-of-prognostics-techniques
- conformal_prediction_notes: https://www.stat.berkeley.edu/~ryantibs/statlearn-s23/lectures/conformal.pdf
- conformal_prediction_intro_arxiv: https://arxiv.org/abs/2107.07511
- conformal_prediction_nixtla: https://nixtlaverse.nixtla.io/statsforecast/docs/tutorials/conformalprediction.html
- shap_paper_arxiv: https://arxiv.org/abs/1705.07874
- shap_docs: http://shap-community.readthedocs.io/
- shap_github: https://github.com/shap/shap
- sklearn_regression_metrics: https://scikit-learn.org/stable/modules/model_evaluation.html
- cmapss_benchmarking_ramasso_saxena: https://ntrs.nasa.gov/api/citations/20150007677/downloads/20150007677.pdf
- regression_metrics_reference: https://www.geeksforgeeks.org/machine-learning/regression-metrics/

---
Collection: `metric_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
