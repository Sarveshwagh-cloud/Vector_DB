# Case Generation Sources

## Purpose

This document records exactly where the `similar_case_rag` cases come from, file by
file, so every retrieved case can be traced back to a real model output. It was
upgraded from generic guidance into a concrete provenance record after the first
real case batch was generated from the inference run
`Final_Inference_Only_HGB_CNN_Ensemble_UQ_ABCD_Full_Metrics` (run id
`20260604_233130`). Each source below is explained as its own point: what the
file contains, why it matters for a case, when it is used, and how it maps into a
case record. Nothing here is invented; fields that the run did not produce are
called out as missing rather than filled in.

## What "real case" means here

A real case is one row of model output turned into a self-contained case summary,
not a raw per-cycle sensor sequence. The run produced 25 inference samples across
five randomly selected engines (units 9, 44, 65, 76, 100; random seed 42; input
`test_final.csv`). Each of those 25 samples became one case JSON under
`cases/`. Because the input file carried no FD001-FD004 label, every case sets
`subset: "unknown_not_labeled_in_this_run"` instead of guessing a subset, and
because the run produced no SHAP artifacts, every case sets
`explainability.shap_top_features: null` with a note, and uses the CNN attention
summary as the only explainability signal. This keeps the collection authentic.

## Primary source: the all-predictions table

`predictions/inference_predictions_with_uq_20260604_233130.csv` is the master
file: 25 rows, 41 columns, one row per sample. It is the spine of every case. Each
case copies its prediction (`predicted_tte`, `boost_pred`, `cnn_pred`,
`ensemble_pred`), its uncertainty (`lower_bound_90/95`, `upper_bound_90/95`,
`interval_width_90/95`, `conformal_q90/q95`), its risk and alarm fields
(`risk_zone`, `predicted_zone`, `critical_alarm_30/33`, `uq_alarm_90/95`,
`uq_risk_zone_90/95`, `recommendation`, `uq_recommendation_90/95`, `confidence`),
and its outcome fields (`actual_tte`, `actual_zone`, `risk_zone_correct`,
`residual`, `absolute_error`, `covered_90/95`). The case's `provenance` block
points back to this file and the exact `sample_index`, so the case is never
anonymous.

## Supporting source: the recommendation-ready table

`predictions/recommendation_ready_predictions_20260604_233130.csv` (25 rows, 23
columns) is the trimmed, decision-facing view of the same samples. It is the file
a live recommender would read, so it confirms the fields that matter most for an
action: `predicted_tte`, `lower_bound_95`, `interval_width_95`, `risk_zone`,
`uq_alarm_95`, `uq_risk_zone_95`, `recommendation`, `uq_recommendation_95`, and
`confidence`. Cases use it to cross-check that the stored recommendation matches
the decision-ready output.

## Supporting source: deployment vs checkpoint splits

`predictions/deployment_current_predictions_20260604_233130.csv` (5 rows) holds
the latest snapshot per engine, and
`predictions/checkpoint_history_predictions_20260604_233130.csv` (20 rows) holds
earlier checkpoints of the same engines. This split is why a case carries
`sample_role` = `deployment_test_like` or `checkpoint_history`: the deployment
rows are the "current decision" cases, while the checkpoint rows let the
recommender show how risk evolved over an engine's life (for example unit 76 moves
from Safe at cycle 74 to Caution at 161 to Critical at 205). Five engine-points
appear in both roles (the latest cycle of each unit); both are kept and remain
distinguishable by `sample_index`.

## Case-type tables (views, used to label and prioritise)

The `tables/` folder does not add new engines; it is pre-sorted views of the same
25 samples, and the generator uses them only to confirm type labels. `tables/
critical_case_details_20260604_233130.csv` (4 rows) is the set of point-critical /
alarmed cases and seeds the `critical_cases` folder. `tables/
top_error_cases_20260604_233130.csv` and `tables/
top_uncertain_cases_width95_20260604_233130.csv` (25 rows each, sorted) drive the
`top_error` and `high_uncertainty` tags. `tables/
coverage_details_20260604_233130.csv` (25 rows) supplies coverage truth.
`tables/not_covered_95_cases_20260604_233130.csv` is empty for this run, which is
why no `not_covered_95` cases exist yet (every sample's 95% interval covered the
true value). `tables/point_risk_zone_counts` and `tables/uq_risk_zone_95_counts`
give the zone distributions quoted in the generation summary.

## Explainability source: CNN attention (SHAP absent)

`recommendation_system_input/attention_summaries/cnn_attention_summaries_for_llm_20260604_233130.json`
(25 entries) gives, per sample, the top attended timesteps with their estimated
cycles and an attention-concentration figure. Each case stores this verbatim under
`explainability.cnn_attention` and adds a one-line reading of where attention sat
in the window (for the critical unit-100 case, attention concentrates on cycles
196-198 — the most recent part of the window, which is consistent with end-of-life
behaviour). SHAP is deliberately empty: `explainability_files` in the LLM input
lists every `hgb_shap_*` artifact as `null`, so cases do not assert any SHAP top
features.

## Context sources: chart summaries, LLM input, metrics, run metadata

`recommendation_system_input/chart_summaries/chart_summaries_20260604_233130.json`
(11 entries) describes the run's distributions in words (for example the 90%
interval width has mean 30.92). `recommendation_system_input/
llm_recommendation_input_20260604_233130.json` is the consolidated payload that
defines the run's risk thresholds (critical 30, alarm 33, warning 60, caution 90)
and the six recommendation modes (balanced, cost_optimized, safety_first,
downtime_minimized, risk_minimized, conservative); cases inherit those thresholds.
`metrics/full_inference_uq_metrics_20260604_233130.json` is the source of the
run-level numbers cited in cases and the summary (RMSE 6.42, MAE 5.54, R2 0.974,
BIAS -2.09, NASA score 16.26, coverage 1.00 at both levels, CFMR and all
decision-CFMRs 0.0, UCE_95 0.05). `reports/inference_run_metadata_20260604_233130.json`
provides the run identity (models, ensemble weights 0.63/0.37, conformal
quantiles, window size 30, the five selected engine ids, and the original pipeline
path), which is copied into each case's `provenance`.

## Evaluation cases vs deployment cases

This run had `target_available_for_all: true`, so every case is an evaluation case
with ground truth, and the outcome fields are real, not pending. In a future
deployment run without ground truth, the same generator should write the same
schema but leave `actual_tte`, `residual`, `absolute_error`, and `covered_*`
empty and mark the case `outcome_type: pending_outcome` until feedback arrives.
The case schema already accommodates both.

## Seed cases and how cases scale

The two user-provided seeds in `case_templates_and_seed_cases/` are kept as
labelled examples (`case_type: user_provided_seed_case`) and are not overwritten.
The 25 generated cases are labelled `case_type: real_inference_case`. To grow the
collection toward the hundreds-to-thousands range the design targets, re-run
inference on more engines (or all engines per subset) and re-run the generator;
each new run appends real cases under `cases/` with its own run id, and the FD
subset can be set when the input is a labelled per-subset file.

## How This Improves Recommendation Reliability

This makes Similar Case RAG auditable. Because each case names the exact file and
`sample_index` it came from, a recommendation that retrieves a case can prove the
evidence is a real model output rather than an invented example, and a reviewer
can open the cited CSV row to verify it. The honest gaps (no subset label, no
SHAP, no not-covered or critical-focus cases this run) are recorded so the
recommender does not over-claim.

## Suggested Metadata Tags

- `case_generation`
- `inference_outputs`
- `provenance`
- `evaluation_cases`
- `deployment_cases`
- `real_inference_case`

## Source Basis

This document is grounded in the user's own inference artifacts from run
`20260604_233130` (predictions, tables, attention summaries, chart summaries,
consolidated LLM input, UQ metrics, and run metadata), plus the CMAPSS dataset
structure. Cases are generated as engine-level or checkpoint-level summaries, not
raw cycle rows. Project-defined items (risk thresholds, custom metrics) are
treated as project-defined; the FD subset and SHAP features are left empty because
this run did not provide them.

## Source URLs / References

- nasa_cmapss_dataset_page: https://data.nasa.gov/dataset/cmapss-jet-engine-simulated-data
- nasa_direct_zip: https://data.nasa.gov/docs/legacy/CMAPSSData.zip
- run_all_predictions: `Final_Inference_Only_HGB_CNN_Ensemble_UQ_ABCD_Full_Metrics/predictions/inference_predictions_with_uq_20260604_233130.csv`
- run_recommendation_ready: `Final_Inference_Only_HGB_CNN_Ensemble_UQ_ABCD_Full_Metrics/predictions/recommendation_ready_predictions_20260604_233130.csv`
- run_attention_summaries: `Final_Inference_Only_HGB_CNN_Ensemble_UQ_ABCD_Full_Metrics/recommendation_system_input/attention_summaries/cnn_attention_summaries_for_llm_20260604_233130.json`
- run_llm_input: `Final_Inference_Only_HGB_CNN_Ensemble_UQ_ABCD_Full_Metrics/recommendation_system_input/llm_recommendation_input_20260604_233130.json`
- run_metrics_json: `Final_Inference_Only_HGB_CNN_Ensemble_UQ_ABCD_Full_Metrics/metrics/full_inference_uq_metrics_20260604_233130.json`
- run_metadata_json: `Final_Inference_Only_HGB_CNN_Ensemble_UQ_ABCD_Full_Metrics/reports/inference_run_metadata_20260604_233130.json`
- generated_cases_root: `similar_case_rag/cases/` (see `case_generation_summary.json` and `cases/_case_index.json`)
- project_custom_metrics: User-provided Custom_Metrics.py definitions

---
Collection: `similar_case_rag`
Dataset: `CMAPSS Jet Engine Simulated Data`
